#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SayF Pool Control - local-first pool table system.

One file. Localhost web app. JSON / JSONL storage. No SQL.
Default language: French. English secondary.

Staff passwords:
- AM shift: am
- PM shift: PM
- Admin: admin

Shift windows:
- AM: 11:00-19:00
- PM: 19:00-03:00, counted on the business date where the PM shift started.

Hardware safety:
- Relay mode is simulation by default.
- Enable real relay only after proper electrical installation.
"""

from __future__ import annotations

import argparse
import csv
import datetime as _dt
import hashlib
import hmac
import io
import json
import os
import platform
import re
import secrets
import shutil
import subprocess
import threading
import time
import uuid
import webbrowser
try:
    from zoneinfo import ZoneInfo
except Exception:  # Python without zoneinfo falls back to system local time.
    ZoneInfo = None
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP_NAME = "SayF Pool Control"
APP_VERSION = "2026.06.07-v12-floor-map-tablet-layout"
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "pool_runtime"
CONFIG_PATH = DATA_DIR / "config.json"
STATE_PATH = DATA_DIR / "state.json"
SESSIONS_PATH = DATA_DIR / "sessions.jsonl"
EVENTS_PATH = DATA_DIR / "events.jsonl"
RELAY_LOG_PATH = DATA_DIR / "relay_log.jsonl"
BACKUP_DIR = DATA_DIR / "backups"
REPORT_SECRET = "TSI-1064880-SayF_361827-pool-report-protection-v1"
AUTH_TOKENS: dict[str, dict] = {}

DEFAULT_CONFIG = {
    "language": "fr",
    "business_name": "Billard",
    "currency": "$",
    "tax_percent": 0.0,
    "tax_divisor": 1.15,
    "max_players_per_table": 4,
    "custom_rate_password": "pool",
    "rounding": 0.05,
    "timezone": "America/Montreal",
    "passwords": {
        "am": "am",
        "pm": "PM",
        "admin": "admin",
    },
    "pricing_options": [
        {
            "id": "am_hourly",
            "fr": "AM 11h-19h - 6$/h (+7$/joueur extra)",
            "en": "AM 11am-7pm - $6/h (+$7/extra player)",
            "kind": "hourly",
            "per_hour": 6.0,
            "flat_amount": 0.0,
            "extra_player_fee": 7.0,
            "included_players": 1,
            "shift": "am",
            "days": [0, 1, 2, 3, 4, 5, 6],
            "staff_selectable": True,
        },
        {
            "id": "am_flat",
            "fr": "AM 11h-19h - 9$ forfait 8h (+7$/joueur extra)",
            "en": "AM 11am-7pm - $9 8h flat (+$7/extra player)",
            "kind": "flat",
            "per_hour": 0.0,
            "flat_amount": 9.0,
            "extra_player_fee": 7.0,
            "included_players": 1,
            "shift": "am",
            "days": [0, 1, 2, 3, 4, 5, 6],
            "staff_selectable": True,
        },
        {
            "id": "pm_12_hourly",
            "fr": "PM - 12$/h (dim, lun, mar, mer, jeu)",
            "en": "PM - $12/h (Sun, Mon, Tue, Wed, Thu)",
            "kind": "hourly",
            "per_hour": 12.0,
            "flat_amount": 0.0,
            "extra_player_fee": 0.0,
            "included_players": 1,
            "shift": "pm",
            "days": [0, 1, 2, 3, 6],
            "staff_selectable": True,
        },
        {
            "id": "pm_mon_tue_flat",
            "fr": "PM lundi/mardi - 20$ forfait 19h-3h",
            "en": "PM Monday/Tuesday - $20 flat 7pm-3am",
            "kind": "flat",
            "per_hour": 0.0,
            "flat_amount": 20.0,
            "extra_player_fee": 0.0,
            "included_players": 1,
            "shift": "pm",
            "days": [0, 1],
            "staff_selectable": True,
        },
        {
            "id": "pm_fri_sat_hourly",
            "fr": "PM vendredi/samedi - 14$/h",
            "en": "PM Friday/Saturday - $14/h",
            "kind": "hourly",
            "per_hour": 14.0,
            "flat_amount": 0.0,
            "extra_player_fee": 0.0,
            "included_players": 1,
            "shift": "pm",
            "days": [4, 5],
            "staff_selectable": True,
        },
    ],
    "tables": [
        {"number": 3, "name": "Table 3", "relay_channel": 1, "enabled": True},
        {"number": 4, "name": "Table 4", "relay_channel": 2, "enabled": True},
        {"number": 5, "name": "Table 5", "relay_channel": 3, "enabled": True},
        {"number": 6, "name": "Table 6", "relay_channel": 4, "enabled": True},
        {"number": 7, "name": "Table 7", "relay_channel": 5, "enabled": True},
        {"number": 8, "name": "Table 8", "relay_channel": 6, "enabled": True},
    ],
    "relay": {
        "enabled": False,
        "mode": "simulation",
        "port": "COM3",
        "baudrate": 9600,
        "protocol": "sainsmart_hex",
        "active_low": False,
        "ascii_on": "RELAY {channel} ON\n",
        "ascii_off": "RELAY {channel} OFF\n",
        "open_after_start": True,
        "close_after_stop": True,
        "close_after_pause": False,
    },
}


def utc_iso(ts: float | None = None) -> str:
    if ts is None:
        ts = time.time()
    return _dt.datetime.fromtimestamp(ts, _dt.UTC).replace(microsecond=0).isoformat()


def app_timezone():
    """Return the configured bar timezone. Default is America/Montreal.

    This avoids wrong AM/PM pricing if the computer, VM, or container is set to UTC.
    """
    tz_name = str(DEFAULT_CONFIG.get("timezone", "America/Montreal"))
    try:
        if CONFIG_PATH.exists():
            raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            tz_name = str(raw.get("timezone") or tz_name)
    except Exception:
        pass
    if ZoneInfo is None:
        return None
    try:
        return ZoneInfo(tz_name)
    except Exception:
        return ZoneInfo("America/Montreal")


def local_dt(ts: float | None = None) -> _dt.datetime:
    tz = app_timezone()
    stamp = time.time() if ts is None else ts
    return _dt.datetime.fromtimestamp(stamp, tz) if tz else _dt.datetime.fromtimestamp(stamp)


def local_date(ts: float | None = None) -> str:
    return local_dt(ts).strftime("%Y-%m-%d")


def parse_date(value: str | None) -> _dt.date | None:
    if not value:
        return None
    try:
        return _dt.date.fromisoformat(str(value)[:10])
    except Exception:
        return None


def iso_to_ts(value: str | float | int | None) -> float:
    if value is None:
        return time.time()
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).replace("Z", "+00:00")
    try:
        return _dt.datetime.fromisoformat(text).timestamp()
    except Exception:
        return time.time()


def shift_for_ts(ts: float | None = None) -> tuple[str, str]:
    """Return (shift_id, business_date). PM after midnight belongs to previous date."""
    dt = local_dt(ts)
    hour = dt.hour + dt.minute / 60.0
    if 11 <= hour < 19:
        return "am", dt.strftime("%Y-%m-%d")
    if hour >= 19:
        return "pm", dt.strftime("%Y-%m-%d")
    if hour < 3:
        prev = dt.date() - _dt.timedelta(days=1)
        return "pm", prev.isoformat()
    # Off-hours fallback. It should not happen in normal bar operation.
    return "am", dt.strftime("%Y-%m-%d")


def current_shift() -> tuple[str, str]:
    return shift_for_ts(time.time())


def day_for_pricing(ts: float | None = None) -> int:
    dt = local_dt(ts)
    # After midnight until 03:00 still belongs to the PM day that started yesterday.
    if dt.hour < 3:
        return (dt.date() - _dt.timedelta(days=1)).weekday()
    return dt.weekday()


def protected_number(prefix: str, *parts: object) -> str:
    base = "|".join([prefix, *[str(p) for p in parts]])
    digest = hmac.new(REPORT_SECRET.encode("utf-8"), base.encode("utf-8"), hashlib.sha256).hexdigest()[:10].upper()
    visible = "-".join(str(p).replace(" ", "") for p in parts if p not in (None, ""))
    return f"{prefix}-{visible}-{digest}" if visible else f"{prefix}-{digest}"


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def append_jsonl(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n")


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    return rows


def deep_merge(base, incoming):
    if not isinstance(base, dict) or not isinstance(incoming, dict):
        return incoming
    out = dict(base)
    for k, v in incoming.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def normalize_tables(tables) -> list[dict]:
    out, seen = [], set()
    for idx, t in enumerate(tables or []):
        try:
            number = int(t.get("number"))
        except Exception:
            continue
        if number in seen:
            continue
        seen.add(number)
        try:
            channel = max(1, min(8, int(t.get("relay_channel", idx + 1))))
        except Exception:
            channel = idx + 1
        out.append({
            "number": number,
            "name": str(t.get("name") or f"Table {number}"),
            "relay_channel": channel,
            "enabled": bool(t.get("enabled", True)),
        })
    return sorted(out or DEFAULT_CONFIG["tables"], key=lambda x: x["number"])


def normalize_pricing_options(options) -> list[dict]:
    out = []
    for i, r in enumerate(options or []):
        rid = str(r.get("id") or f"pricing_{i+1}").strip().replace(" ", "_")
        kind = str(r.get("kind") or "hourly").lower().strip()
        if kind not in ("hourly", "flat"):
            kind = "hourly"
        try:
            days = [int(x) for x in (r.get("days") or [0, 1, 2, 3, 4, 5, 6])]
        except Exception:
            days = [0, 1, 2, 3, 4, 5, 6]
        out.append({
            "id": rid,
            "fr": str(r.get("fr") or r.get("name") or rid),
            "en": str(r.get("en") or r.get("name") or rid),
            "kind": kind,
            "per_hour": max(0.0, float(r.get("per_hour") or 0)),
            "flat_amount": max(0.0, float(r.get("flat_amount") or 0)),
            "extra_player_fee": max(0.0, float(r.get("extra_player_fee") or 0)),
            "included_players": max(1, int(r.get("included_players") or 1)),
            "shift": str(r.get("shift") or "any").lower(),
            "days": days,
            "staff_selectable": bool(r.get("staff_selectable", True)),
        })
    return out or DEFAULT_CONFIG["pricing_options"]


def load_config() -> dict:
    cfg = deep_merge(DEFAULT_CONFIG, load_json(CONFIG_PATH, {}))
    cfg["tables"] = normalize_tables(cfg.get("tables"))
    cfg["pricing_options"] = normalize_pricing_options(cfg.get("pricing_options"))
    cfg.setdefault("passwords", dict(DEFAULT_CONFIG["passwords"]))
    cfg.setdefault("relay", dict(DEFAULT_CONFIG["relay"]))
    cfg.setdefault("tax_divisor", DEFAULT_CONFIG["tax_divisor"])
    cfg.setdefault("max_players_per_table", DEFAULT_CONFIG["max_players_per_table"])
    cfg.setdefault("custom_rate_password", DEFAULT_CONFIG["custom_rate_password"])
    return cfg


def public_config(cfg: dict | None = None) -> dict:
    cfg = load_config() if cfg is None else cfg
    out = json.loads(json.dumps(cfg, ensure_ascii=False))
    out.pop("passwords", None)
    out["passwords_set"] = True
    return out



def table_template(number: int) -> dict:
    return {
        "number": int(number),
        "status": "off",
        "session_id": None,
        "bill_number": None,
        "client": "",
        "pricing_id": None,
        "pricing_name_fr": "",
        "pricing_name_en": "",
        "pricing_kind": "hourly",
        "rate_per_hour": 0.0,
        "flat_amount": 0.0,
        "extra_player_fee": 0.0,
        "included_players": 1,
        "players": [],
        "max_players": 0,
        "started_at": None,
        "paused_at": None,
        "paused_total": 0.0,
        "adjustments": [],
        "player_cashouts": [],
        "notes": "",
        "relay_on": False,
        "last_total": 0.0,
    }


def fresh_state(cfg: dict | None = None) -> dict:
    cfg = load_config() if cfg is None else cfg
    return {
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
        "tables": {str(t["number"]): table_template(t["number"]) for t in cfg.get("tables", [])},
    }


def migrate_table(t: dict, number: int) -> dict:
    base = table_template(number)
    if isinstance(t, dict):
        base.update(t)
    base["number"] = int(number)
    if not isinstance(base.get("players"), list):
        count = max(1, int(base.get("player_count") or 1)) if base.get("status") != "off" else 0
        base["players"] = [player_template(f"Joueur {i+1}", number, i + 1) for i in range(min(count, 4))]
    if base.get("status") == "off":
        base["players"] = []
        base["max_players"] = 0
    else:
        active = active_players_list(base)[:4]
        inactive = [p for p in base.get("players", []) if not p.get("active", True)]
        base["players"] = active + inactive
        normalize_player_slots_for_table(base, number, load_config() if CONFIG_PATH.exists() else DEFAULT_CONFIG)
        active_count = len(active_players_list(base))
        base["max_players"] = max(min(int(base.get("max_players") or 0), 4), active_count, 1)
    return base


def ensure_runtime() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_PATH.exists():
        save_json(CONFIG_PATH, DEFAULT_CONFIG)
    if not STATE_PATH.exists():
        save_json(STATE_PATH, fresh_state(load_config()))
    for p in (SESSIONS_PATH, EVENTS_PATH, RELAY_LOG_PATH):
        if not p.exists():
            p.write_text("", encoding="utf-8")


def load_state() -> dict:
    cfg = load_config()
    state = load_json(STATE_PATH, fresh_state(cfg))
    if not isinstance(state, dict):
        state = fresh_state(cfg)
    tables = state.setdefault("tables", {})
    valid = {str(t["number"]) for t in cfg.get("tables", [])}
    for table_cfg in cfg.get("tables", []):
        key = str(table_cfg["number"])
        tables[key] = migrate_table(tables.get(key, {}), table_cfg["number"])
    state["tables"] = {k: v for k, v in tables.items() if k in valid}
    return state


def save_state(state: dict) -> None:
    state["updated_at"] = utc_iso()
    save_json(STATE_PATH, state)


def event(action: str, table=None, user=None, **extra) -> None:
    row = {
        "ts": utc_iso(),
        "local_date": local_date(),
        "action": action,
    }
    if table is not None:
        row["table"] = int(table)
    if user:
        row["user"] = {k: user.get(k) for k in ("role", "shift", "label") if k in user}
    row.update(extra)
    append_jsonl(EVENTS_PATH, row)


def money_round(value: float, nearest: float = 0.05) -> float:
    try:
        nearest = float(nearest)
    except Exception:
        nearest = 0.05
    if nearest <= 0:
        return round(float(value), 2)
    return round(round(float(value) / nearest) * nearest, 2)


def money(value: float, cfg: dict | None = None) -> str:
    cfg = load_config() if cfg is None else cfg
    return f"{cfg.get('currency', '$')}{float(value):.2f}"


def tax_divisor(cfg: dict | None = None) -> float:
    cfg = load_config() if cfg is None else cfg
    try:
        div = float(cfg.get("tax_divisor") or 1.15)
    except Exception:
        div = 1.15
    return div if div > 0 else 1.15


def total_without_tax_from_total(total: float, cfg: dict | None = None) -> float:
    cfg = load_config() if cfg is None else cfg
    return round(max(0.0, float(total or 0.0)) / tax_divisor(cfg), 2)


def included_tax_from_total(total: float, cfg: dict | None = None) -> float:
    total = max(0.0, float(total or 0.0))
    return round(total - total_without_tax_from_total(total, cfg), 2)


def max_players_allowed(cfg: dict | None = None) -> int:
    cfg = load_config() if cfg is None else cfg
    try:
        value = int(cfg.get("max_players_per_table") or 4)
    except Exception:
        value = 4
    return max(1, min(4, value))


def make_player_id(table: int | str, slot: int | str) -> str:
    return f"T{int(table)}P{int(slot)}"


def active_players_list(t: dict) -> list[dict]:
    return [p for p in (t.get("players") or []) if p.get("active", True)]


def player_slot_value(p: dict, table: int | str | None = None) -> int | None:
    try:
        slot = int(p.get("slot"))
        if 1 <= slot <= 4:
            return slot
    except Exception:
        pass
    pid = str(p.get("id") or "")
    m = re.match(r"^T(\d+)P([1-4])$", pid)
    if m and (table is None or int(m.group(1)) == int(table)):
        return int(m.group(2))
    return None


def used_active_slots(t: dict, table: int | str) -> set[int]:
    used: set[int] = set()
    for p in active_players_list(t):
        slot = player_slot_value(p, table)
        if slot:
            used.add(slot)
    return used


def next_player_slot(t: dict, table: int | str, cfg: dict | None = None) -> int | None:
    allowed = max_players_allowed(cfg)
    used = used_active_slots(t, table)
    for slot in range(1, allowed + 1):
        if slot not in used:
            return slot
    return None


def deterministic_player(name: str = "", table: int | str | None = None, slot: int | str | None = None) -> dict:
    if table is None or slot is None:
        pid = "T0P0"
        slot_value = 0
    else:
        slot_value = int(slot)
        pid = make_player_id(table, slot_value)
    return {
        "id": pid,
        "slot": slot_value,
        "name": str(name or (f"Joueur {slot_value}" if slot_value else "Joueur")),
        "joined_at": utc_iso(),
        "active": True,
        "removed_at": None,
        "notes": "",
    }


def normalize_player_slots_for_table(t: dict, table: int | str, cfg: dict | None = None) -> dict:
    """Keep deterministic table/slot IDs without shifting occupied slots.

    Earlier builds compacted active players back to P1/P2/P3. That is bad for a
    cashier tablet because T3P2 must remain T3P2 after T3P1 leaves or cashes out.
    This function preserves valid slot numbers, fixes IDs to T{table}P{slot}, and
    only assigns the next free slot when a player has no valid slot.
    """
    allowed = max_players_allowed(cfg)
    used: set[int] = set()
    free = [i for i in range(1, allowed + 1)]
    for p in t.get("players", []) or []:
        slot = player_slot_value(p, table)
        if slot and 1 <= slot <= allowed and slot not in used:
            chosen = slot
        else:
            chosen = free[0] if free else None
        if chosen is None:
            continue
        if chosen in free:
            free.remove(chosen)
        used.add(chosen)
        old_id = str(p.get("id") or "")
        new_id = make_player_id(table, chosen)
        if old_id and old_id != new_id:
            p.setdefault("previous_ids", [])
            if old_id not in p["previous_ids"]:
                p["previous_ids"].append(old_id)
        p["slot"] = chosen
        p["id"] = new_id
    return t


def player_template(name: str = "", table: int | str | None = None, slot: int | str | None = None) -> dict:
    return deterministic_player(name, table, slot)


def elapsed_seconds(t: dict, now: float | None = None) -> float:
    now = time.time() if now is None else now
    if t.get("status") == "off" or not t.get("started_at"):
        return 0.0
    elapsed = now - float(t.get("started_at") or now)
    elapsed -= float(t.get("paused_total") or 0.0)
    if t.get("status") == "paused" and t.get("paused_at"):
        elapsed -= now - float(t.get("paused_at"))
    return max(0.0, elapsed)


def participant_count(t: dict) -> int:
    return max(1, active_player_count(t), int(t.get("max_players") or 0))


def active_player_count(t: dict) -> int:
    return len([p for p in t.get("players", []) if p.get("active", True)])


def subtotal_for(t: dict, cfg: dict | None = None, now: float | None = None) -> float:
    cfg = load_config() if cfg is None else cfg
    kind = str(t.get("pricing_kind") or "hourly")
    if kind == "flat":
        base = float(t.get("flat_amount") or 0.0)
    else:
        base = elapsed_seconds(t, now) / 3600.0 * float(t.get("rate_per_hour") or 0.0)
    charged_players = max(int(t.get("max_players") or 0), participant_count(t), active_player_count(t), 1)
    included = max(1, int(t.get("included_players") or 1))
    extra_fee = max(0.0, float(t.get("extra_player_fee") or 0.0))
    extras = max(0, charged_players - included) * extra_fee
    adjustments = 0.0
    for a in t.get("adjustments") or []:
        try:
            adjustments += float(a.get("amount") or 0)
        except Exception:
            pass
    return money_round(max(0.0, base + extras + adjustments), float(cfg.get("rounding", 0.05)))


def total_with_tax(subtotal: float, cfg: dict | None = None) -> tuple[float, float]:
    cfg = load_config() if cfg is None else cfg
    tax_percent = float(cfg.get("tax_percent") or 0.0)
    tax = round(max(0.0, subtotal) * tax_percent / 100.0, 2)
    total = money_round(subtotal + tax, float(cfg.get("rounding", 0.05)))
    return tax, total


def paid_total_for_table(t: dict) -> float:
    total = 0.0
    for row in t.get("player_cashouts") or []:
        if row.get("paid", True):
            try:
                total += float(row.get("total") or 0.0)
            except Exception:
                pass
    return round(total, 2)


def billed_player_ids_for_table(t: dict) -> set[str]:
    return {str(row.get("player_id")) for row in (t.get("player_cashouts") or []) if row.get("player_id")}


def billable_player_count(t: dict) -> int:
    return max(1, int(t.get("max_players") or 0), active_player_count(t), len(t.get("players") or []))


def active_unpaid_players_list(t: dict) -> list[dict]:
    billed = billed_player_ids_for_table(t)
    return [p for p in active_players_list(t) if str(p.get("id") or "") not in billed]


def player_running_allocations(t: dict, cfg: dict | None = None, now: float | None = None) -> dict[str, dict]:
    """Current amount owed by each active, unpaid player.

    This is the cashier-facing split. It always uses the remaining table balance
    after previous player cashouts, so a player cashout is immediately removed
    from the general table bill. Example: $20 flat / 4 players = $5 each; after
    one $5 cashout, the table due becomes $15 and the three remaining players
    continue to show $5 each.
    """
    cfg = load_config() if cfg is None else cfg
    now = time.time() if now is None else now
    players = sorted(active_unpaid_players_list(t), key=lambda p: player_slot_value(p, t.get("number") or 0) or 99)
    if not players:
        return {}
    totals = session_totals_for_table(t, cfg, now)
    due = money_round(float(totals.get("due_total") or 0.0), float(cfg.get("rounding", 0.05)))
    rounding = float(cfg.get("rounding", 0.05))
    out: dict[str, dict] = {}
    allocated = 0.0
    share_count = len(players)
    raw_share = due / max(1, share_count)
    for idx, p in enumerate(players):
        pid = str(p.get("id") or "")
        if idx == share_count - 1:
            amount = money_round(max(0.0, due - allocated), rounding)
        else:
            amount = money_round(min(raw_share, max(0.0, due - allocated)), rounding)
            allocated = round(allocated + amount, 2)
        out[pid] = {
            "player_id": pid,
            "running_total": amount,
            "running_without_tax": total_without_tax_from_total(amount, cfg),
            "running_tax_included": included_tax_from_total(amount, cfg),
            "remaining_table_total": due,
            "split_count": share_count,
        }
    return out


def session_totals_for_table(t: dict, cfg: dict | None = None, now: float | None = None) -> dict:
    cfg = load_config() if cfg is None else cfg
    subtotal = subtotal_for(t, cfg, now)
    tax, total = total_with_tax(subtotal, cfg)
    paid_total = paid_total_for_table(t)
    due = money_round(max(0.0, total - paid_total), float(cfg.get("rounding", 0.05)))
    return {
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "paid_total": paid_total,
        "due_total": due,
        "total_without_tax": total_without_tax_from_total(total, cfg),
        "tax_included": included_tax_from_total(total, cfg),
        "due_without_tax": total_without_tax_from_total(due, cfg),
        "due_tax_included": included_tax_from_total(due, cfg),
    }


def get_table_config(cfg: dict, table_number: int | str) -> dict:
    for t in cfg.get("tables", []):
        if int(t.get("number")) == int(table_number):
            return t
    raise KeyError(f"Table inconnue: {table_number}")


def get_pricing_option(cfg: dict, pricing_id: str | None) -> dict:
    for p in cfg.get("pricing_options", []):
        if str(p.get("id")) == str(pricing_id):
            return p
    return cfg.get("pricing_options", [DEFAULT_CONFIG["pricing_options"][0]])[0]


def is_pricing_allowed(pricing: dict, ts: float | None = None) -> bool:
    shift_id, _business_date = shift_for_ts(ts)
    p_shift = str(pricing.get("shift") or "any").lower()
    if p_shift not in ("any", shift_id):
        return False
    return day_for_pricing(ts) in set(int(x) for x in pricing.get("days") or [])


def allowed_pricing_options(cfg: dict | None = None, ts: float | None = None) -> list[dict]:
    cfg = load_config() if cfg is None else cfg
    return [p for p in cfg.get("pricing_options", []) if bool(p.get("staff_selectable", True)) and is_pricing_allowed(p, ts)]


def recommended_pricing_id(ts: float | None = None) -> str:
    opts = allowed_pricing_options(load_config(), ts)
    # Prefer hourly default; flat must be actively chosen by button.
    for p in opts:
        if p.get("kind") == "hourly":
            return str(p.get("id"))
    return str(opts[0].get("id")) if opts else "am_hourly"


class RelayDriver:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.relay_cfg = cfg.get("relay", {})

    def send(self, channel: int, logical_on: bool) -> dict:
        channel = int(channel)
        logical_on = bool(logical_on)
        enabled = bool(self.relay_cfg.get("enabled"))
        mode = str(self.relay_cfg.get("mode", "simulation"))
        physical_on = (not logical_on) if bool(self.relay_cfg.get("active_low")) else logical_on
        payload = self._payload(channel, physical_on)
        log = {
            "ts": utc_iso(),
            "local_date": local_date(),
            "channel": channel,
            "logical_on": logical_on,
            "physical_on": physical_on,
            "enabled": enabled,
            "mode": mode,
            "protocol": self.relay_cfg.get("protocol"),
            "port": self.relay_cfg.get("port"),
            "payload_hex": payload.hex(" "),
        }
        if not enabled or mode == "simulation":
            log.update({"ok": True, "simulated": True, "message": "Simulation / hardware disabled"})
            append_jsonl(RELAY_LOG_PATH, log)
            return {"ok": True, "simulated": True, "message": "Simulation / hardware disabled"}
        try:
            self._write_serial(payload)
            log.update({"ok": True, "simulated": False, "message": "Sent"})
            append_jsonl(RELAY_LOG_PATH, log)
            return {"ok": True, "simulated": False, "message": "Sent"}
        except Exception as exc:
            log.update({"ok": False, "simulated": False, "message": str(exc)})
            append_jsonl(RELAY_LOG_PATH, log)
            return {"ok": False, "simulated": False, "message": str(exc)}

    def _payload(self, channel: int, physical_on: bool) -> bytes:
        protocol = str(self.relay_cfg.get("protocol", "sainsmart_hex"))
        if protocol == "ascii_template":
            key = "ascii_on" if physical_on else "ascii_off"
            tmpl = str(self.relay_cfg.get(key) or "RELAY {channel} {state}\n")
            return tmpl.format(channel=channel, state=("ON" if physical_on else "OFF"), value=(1 if physical_on else 0)).encode("utf-8")
        state_byte = 0x01 if physical_on else 0x00
        checksum = (0xA0 + channel + state_byte) & 0xFF
        return bytes([0xA0, channel & 0xFF, state_byte, checksum])

    def _write_serial(self, payload: bytes) -> None:
        port = str(self.relay_cfg.get("port") or "COM3")
        baud = int(self.relay_cfg.get("baudrate") or 9600)
        try:
            import serial  # type: ignore
            with serial.Serial(port, baudrate=baud, timeout=1) as ser:
                ser.write(payload)
                ser.flush()
            return
        except ImportError:
            pass
        if os.name == "posix":
            self._write_posix_serial(port, baud, payload)
            return
        win_port = port if port.startswith("\\\\.\\") else "\\\\.\\" + port
        with open(win_port, "wb", buffering=0) as f:
            f.write(payload)

    @staticmethod
    def _write_posix_serial(port: str, baud: int, payload: bytes) -> None:
        import termios
        baud_map = {9600: termios.B9600, 19200: termios.B19200, 38400: termios.B38400, 57600: termios.B57600, 115200: termios.B115200}
        fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_SYNC)
        try:
            attrs = termios.tcgetattr(fd)
            speed = baud_map.get(baud, termios.B9600)
            attrs[4] = speed
            attrs[5] = speed
            attrs[2] = attrs[2] | termios.CLOCAL | termios.CREAD
            attrs[2] = attrs[2] & ~termios.CSIZE | termios.CS8
            attrs[2] = attrs[2] & ~termios.PARENB
            attrs[2] = attrs[2] & ~termios.CSTOPB
            attrs[2] = attrs[2] & ~termios.CRTSCTS
            attrs[0] = attrs[0] & ~(termios.IXON | termios.IXOFF | termios.IXANY)
            attrs[1] = attrs[1] & ~termios.OPOST
            attrs[3] = attrs[3] & ~(termios.ICANON | termios.ECHO | termios.ECHOE | termios.ISIG)
            termios.tcsetattr(fd, termios.TCSANOW, attrs)
            os.write(fd, payload)
            termios.tcdrain(fd)
        finally:
            os.close(fd)


def set_relay_for_table(cfg: dict, table: int, on: bool) -> dict:
    ch = int(get_table_config(cfg, table).get("relay_channel"))
    return RelayDriver(cfg).send(ch, on)


def enrich_state(state: dict | None = None, cfg: dict | None = None) -> dict:
    cfg = load_config() if cfg is None else cfg
    state = load_state() if state is None else state
    now = time.time()
    out = json.loads(json.dumps(state, ensure_ascii=False))
    for key, t in out.get("tables", {}).items():
        subtotal = subtotal_for(t, cfg, now)
        tax, total = total_with_tax(subtotal, cfg)
        t["elapsed_seconds"] = int(elapsed_seconds(t, now))
        t["subtotal"] = subtotal
        t["tax"] = tax
        t["total_without_tax"] = total_without_tax_from_total(total, cfg)
        t["tax_included"] = included_tax_from_total(total, cfg)
        t["total"] = total
        paid_total = paid_total_for_table(t)
        due_total = money_round(max(0.0, total - paid_total), float(cfg.get("rounding", 0.05)))
        t["paid_total"] = paid_total
        t["due_total"] = due_total
        t["due_without_tax"] = total_without_tax_from_total(due_total, cfg)
        t["due_tax_included"] = included_tax_from_total(due_total, cfg)
        t["active_players"] = active_player_count(t)
        t["participant_count"] = participant_count(t)
        allocations = player_running_allocations(t, cfg, now) if t.get("status") != "off" else {}
        t["player_running_totals"] = allocations
        for p in t.get("players", []) or []:
            pid = str(p.get("id") or "")
            if pid in allocations:
                p.update(allocations[pid])
            elif p.get("cashed_out") or p.get("cashout_bill_number"):
                paid_amt = float(p.get("cashout_total") or 0.0)
                p["running_total"] = 0.0
                p["paid_total"] = paid_amt
                p["cashout_without_tax"] = total_without_tax_from_total(paid_amt, cfg)
                p["cashout_tax_included"] = included_tax_from_total(paid_amt, cfg)
            else:
                p["running_total"] = 0.0
                p["running_without_tax"] = 0.0
                p["running_tax_included"] = 0.0
        try:
            tc = get_table_config(cfg, key)
            t["relay_channel"] = tc.get("relay_channel")
            t["name"] = tc.get("name")
            t["enabled"] = tc.get("enabled", True)
        except Exception:
            pass
    return {
        "ok": True,
        "app": APP_NAME,
        "version": APP_VERSION,
        "server_time": utc_iso(),
        "local_date": local_date(),
        "timezone": str((app_timezone() or "system-local")),
        "current_shift": {"id": current_shift()[0], "business_date": current_shift()[1]},
        "allowed_pricing": allowed_pricing_options(cfg),
        "pricing_catalog": [dict(p, available=is_pricing_allowed(p)) for p in cfg.get("pricing_options", []) if bool(p.get("staff_selectable", True))],
        "config": public_config(cfg),
        "state": out,
    }


def current_user(headers) -> dict | None:
    raw = headers.get("Cookie") or ""
    c = cookies.SimpleCookie()
    try:
        c.load(raw)
    except Exception:
        return None
    sid = c.get("pool_sid")
    if not sid:
        return None
    user = AUTH_TOKENS.get(sid.value)
    if not user:
        return None
    return user


def check_login(password: str) -> dict | None:
    cfg = load_config()
    pw = cfg.get("passwords", {})
    shift_id, business_date = current_shift()
    clean_password = str(password or "").strip()
    admin_password = str(pw.get("admin", "admin")).strip()
    am_password = str(pw.get("am", "am")).strip()
    pm_password = str(pw.get("pm", "PM")).strip()

    # Admin password for this build is admin. Keep config-compatible fallback for upgrades.
    if clean_password == "admin" or clean_password == admin_password:
        return {"role": "admin", "shift": "admin", "label": "Admin", "business_date": business_date, "signed_in_at": utc_iso()}

    # Shift passwords are operator-friendly: AM/am and PM/pm both work.
    if clean_password.lower() == am_password.lower() or clean_password.upper() == "AM":
        return {"role": "staff", "shift": "am", "label": "AM", "business_date": business_date, "signed_in_at": utc_iso()}
    if clean_password.lower() == pm_password.lower() or clean_password.upper() == "PM":
        return {"role": "staff", "shift": "pm", "label": "PM", "business_date": business_date, "signed_in_at": utc_iso()}
    return None


def require_user(headers) -> tuple[bool, dict | None, dict | None]:
    user = current_user(headers)
    if not user:
        return False, None, {"ok": False, "error": "Connexion requise."}
    return True, user, None


def require_admin(headers) -> tuple[bool, dict | None, dict | None]:
    ok, user, err = require_user(headers)
    if not ok:
        return False, None, err
    if user.get("role") != "admin":
        return False, user, {"ok": False, "error": "Accès admin requis."}
    return True, user, None


def custom_pricing_from_payload(payload: dict, user: dict, cfg: dict) -> tuple[bool, str, dict | None]:
    custom = payload.get("custom_rate")
    if not custom:
        return False, "", None
    password = str(payload.get("custom_password") or custom.get("password") or "").strip()
    required = str(cfg.get("custom_rate_password") or "pool").strip()
    if user.get("role") != "admin" and password != required:
        return False, "Mot de passe tarif custom requis.", None
    kind = str(custom.get("kind") or "hourly").lower().strip()
    if kind not in ("hourly", "flat"):
        kind = "hourly"
    try:
        amount = float(custom.get("amount") or 0)
    except Exception:
        return False, "Montant custom invalide.", None
    if amount <= 0:
        return False, "Montant custom invalide.", None
    amount = money_round(amount, float(cfg.get("rounding", 0.05)))
    label = f"CUSTOM {'$/h' if kind == 'hourly' else 'forfait'} {amount:.2f}$"
    return True, "", {
        "id": f"custom_{kind}_{amount:.2f}",
        "fr": label,
        "en": label,
        "kind": kind,
        "per_hour": amount if kind == "hourly" else 0.0,
        "flat_amount": amount if kind == "flat" else 0.0,
        "extra_player_fee": float(custom.get("extra_player_fee") or 0.0),
        "included_players": 1,
        "shift": "any",
        "days": [0, 1, 2, 3, 4, 5, 6],
        "staff_selectable": False,
        "custom": True,
    }


def start_table(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    key = str(table)
    if key not in state["tables"]:
        return False, "Table inconnue.", None
    t = state["tables"][key]
    if t.get("status") != "off":
        return False, "La table est déjà ouverte.", None
    now = time.time()

    custom_ok, custom_msg, custom_pricing = custom_pricing_from_payload(payload, user, cfg)
    if payload.get("custom_rate") and not custom_ok:
        return False, custom_msg, None
    if custom_pricing:
        pricing = custom_pricing
        pricing_id = str(pricing.get("id"))
    else:
        pricing_id = str(payload.get("pricing_id") or recommended_pricing_id(now))
        pricing = get_pricing_option(cfg, pricing_id)
        if user.get("role") != "admin" and not is_pricing_allowed(pricing, now):
            return False, "Ce tarif n'est pas disponible maintenant.", None

    names = payload.get("players") or []
    if isinstance(names, str):
        names = [x.strip() for x in names.split(",") if x.strip()]
    names = [str(x or "").strip() for x in names if str(x or "").strip()]
    if not names:
        first = str(payload.get("player_name") or payload.get("client") or "Joueur 1").strip()
        names = [first or "Joueur 1"]
    allowed = max_players_allowed(cfg)
    if len(names) > allowed:
        return False, f"Maximum {allowed} joueurs par table.", None
    raw_slots = payload.get("player_slots") or []
    slots: list[int] = []
    if isinstance(raw_slots, list):
        for x in raw_slots:
            try:
                val = int(x)
            except Exception:
                continue
            if 1 <= val <= allowed and val not in slots:
                slots.append(val)
    slots = sorted(slots)[:allowed]
    if not slots or len(slots) != len(names):
        slots = list(range(1, len(names) + 1))
    players = [player_template(name, table, slot) for name, slot in zip(names, slots)]
    session_id = uuid.uuid4().hex
    bill_number = protected_number("BILL", local_dt(now).strftime("%Y%m%d"), table, session_id[:8])
    shift_id, business_date = shift_for_ts(now)
    t.update({
        "status": "running",
        "session_id": session_id,
        "bill_number": bill_number,
        "client": str(payload.get("client") or names[0] or ""),
        "pricing_id": str(pricing.get("id")),
        "pricing_name_fr": str(pricing.get("fr")),
        "pricing_name_en": str(pricing.get("en")),
        "pricing_kind": str(pricing.get("kind") or "hourly"),
        "rate_per_hour": float(pricing.get("per_hour") or 0),
        "flat_amount": float(pricing.get("flat_amount") or 0),
        "extra_player_fee": float(pricing.get("extra_player_fee") or 0),
        "included_players": int(pricing.get("included_players") or 1),
        "players": players,
        "max_players": max(1, len(players)),
        "started_at": now,
        "paused_at": None,
        "paused_total": 0.0,
        "adjustments": [],
        "player_cashouts": [],
        "notes": str(payload.get("notes") or ""),
        "shift_id": shift_id,
        "business_date": business_date,
        "opened_by": user.get("label"),
        "custom_rate": bool(pricing.get("custom")),
    })
    normalize_player_slots_for_table(t, table, cfg)
    relay = {"ok": True, "message": "Relay not requested"}
    if cfg.get("relay", {}).get("open_after_start", True):
        relay = set_relay_for_table(cfg, table, True)
        if relay.get("ok"):
            t["relay_on"] = True
    save_state(state)
    event("table_start", table, user, session_id=session_id, bill_number=bill_number, pricing_id=pricing_id, players=len(players), relay=relay, custom_rate=bool(pricing.get("custom")))
    return True, "Table ouverte.", enrich_state(state, cfg)


def pause_table(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    t = state["tables"].get(str(table))
    if not t or t.get("status") != "running":
        return False, "La table n'est pas en cours.", None
    t["status"] = "paused"
    t["paused_at"] = time.time()
    relay = {"ok": True, "message": "Relay not requested"}
    if cfg.get("relay", {}).get("close_after_pause", False):
        relay = set_relay_for_table(cfg, table, False)
        if relay.get("ok"):
            t["relay_on"] = False
    save_state(state)
    event("table_pause", table, user, session_id=t.get("session_id"), relay=relay)
    return True, "Table en pause.", enrich_state(state, cfg)


def resume_table(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    t = state["tables"].get(str(table))
    if not t or t.get("status") != "paused":
        return False, "La table n'est pas en pause.", None
    now = time.time()
    if t.get("paused_at"):
        t["paused_total"] = float(t.get("paused_total") or 0) + max(0.0, now - float(t.get("paused_at")))
    t["status"] = "running"
    t["paused_at"] = None
    relay = {"ok": True, "message": "Relay not requested"}
    if cfg.get("relay", {}).get("open_after_start", True):
        relay = set_relay_for_table(cfg, table, True)
        if relay.get("ok"):
            t["relay_on"] = True
    save_state(state)
    event("table_resume", table, user, session_id=t.get("session_id"), relay=relay)
    return True, "Table reprise.", enrich_state(state, cfg)


def add_player(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    t = state["tables"].get(str(table))
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    allowed = max_players_allowed(cfg)
    if active_player_count(t) >= allowed:
        return False, f"Maximum {allowed} joueurs par table.", None
    slot = next_player_slot(t, table, cfg)
    if not slot:
        return False, f"Aucun slot joueur disponible. Maximum {allowed}.", None
    name = str(payload.get("name") or f"Joueur {slot}").strip()
    p = player_template(name, table, slot)
    t.setdefault("players", []).append(p)
    normalize_player_slots_for_table(t, table, cfg)
    t["max_players"] = max(int(t.get("max_players") or 0), active_player_count(t))
    save_state(state)
    event("player_add", table, user, session_id=t.get("session_id"), player_id=p["id"], player_name=p["name"], slot=slot)
    return True, "Joueur ajouté.", enrich_state(state, cfg)


def update_player(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    player_id = str(payload.get("player_id") or "")
    t = state["tables"].get(str(table))
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    for p in t.get("players", []):
        if p.get("id") == player_id:
            if "name" in payload:
                p["name"] = str(payload.get("name") or p.get("name") or "Joueur")
            if "notes" in payload:
                p["notes"] = str(payload.get("notes") or "")
            save_state(state)
            event("player_update", table, user, session_id=t.get("session_id"), player_id=player_id, player_name=p.get("name"))
            return True, "Joueur mis à jour.", enrich_state(state, cfg)
    return False, "Joueur introuvable.", None


def remove_player(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    player_id = str(payload.get("player_id") or "")
    t = state["tables"].get(str(table))
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    active = [p for p in t.get("players", []) if p.get("active", True)]
    if len(active) <= 1:
        return False, "Il doit rester au moins un joueur actif.", None
    for p in t.get("players", []):
        if p.get("id") == player_id and p.get("active", True):
            p["active"] = False
            p["removed_at"] = utc_iso()
            p["remove_reason"] = str(payload.get("reason") or "Retiré")
            save_state(state)
            event("player_remove", table, user, session_id=t.get("session_id"), player_id=player_id, player_name=p.get("name"))
            return True, "Joueur retiré.", enrich_state(state, cfg)
    return False, "Joueur introuvable.", None


def transfer_player(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    src = int(payload.get("from_table"))
    dst = int(payload.get("to_table"))
    player_id = str(payload.get("player_id") or "")
    if src == dst:
        return False, "Même table.", None
    src_t = state["tables"].get(str(src))
    dst_t = state["tables"].get(str(dst))
    if not src_t or src_t.get("status") == "off":
        return False, "Table source inactive.", None
    if not dst_t:
        return False, "Table destination inconnue.", None
    allowed = max_players_allowed(cfg)
    if dst_t.get("status") != "off" and active_player_count(dst_t) >= allowed:
        return False, f"La table destination a déjà {allowed} joueurs.", None
    player = None
    for p in src_t.get("players", []):
        if p.get("id") == player_id and p.get("active", True):
            player = p
            break
    if not player:
        return False, "Joueur introuvable.", None
    active_src = [p for p in src_t.get("players", []) if p.get("active", True)]
    if len(active_src) <= 1:
        return False, "Impossible de transférer le dernier joueur. Utilise transfert de table complète.", None

    source_copy = json.loads(json.dumps(player, ensure_ascii=False))
    source_copy["active"] = False
    source_copy["removed_at"] = utc_iso()
    source_copy["transferred_to_table"] = dst
    source_copy["remove_reason"] = f"Transféré à la table {dst}"
    for idx, existing in enumerate(src_t.get("players", [])):
        if existing.get("id") == player_id:
            src_t["players"][idx] = source_copy
            break

    player = json.loads(json.dumps(player, ensure_ascii=False))
    player["active"] = True
    player["joined_at"] = utc_iso()
    player["transferred_at"] = utc_iso()
    player["from_table"] = src
    player.setdefault("previous_ids", [])
    if player_id not in player["previous_ids"]:
        player["previous_ids"].append(player_id)

    if dst_t.get("status") == "off":
        now = time.time()
        pricing = get_pricing_option(cfg, payload.get("pricing_id") or recommended_pricing_id(now))
        if user.get("role") != "admin" and not is_pricing_allowed(pricing, now):
            return False, "Ce tarif n'est pas disponible maintenant.", None
        session_id = uuid.uuid4().hex
        shift_id, business_date = shift_for_ts(now)
        player["slot"] = 1
        player["id"] = make_player_id(dst, 1)
        dst_t.update({
            "status": "running",
            "session_id": session_id,
            "bill_number": protected_number("BILL", local_dt(now).strftime("%Y%m%d"), dst, session_id[:8]),
            "client": player.get("name") or "Joueur",
            "pricing_id": str(pricing.get("id")),
            "pricing_name_fr": str(pricing.get("fr")),
            "pricing_name_en": str(pricing.get("en")),
            "pricing_kind": str(pricing.get("kind") or "hourly"),
            "rate_per_hour": float(pricing.get("per_hour") or 0),
            "flat_amount": float(pricing.get("flat_amount") or 0),
            "extra_player_fee": float(pricing.get("extra_player_fee") or 0),
            "included_players": int(pricing.get("included_players") or 1),
            "players": [player],
            "max_players": 1,
            "started_at": now,
            "paused_at": None,
            "paused_total": 0.0,
            "adjustments": [],
            "player_cashouts": [],
            "notes": f"Joueur transféré de la table {src}",
            "shift_id": shift_id,
            "business_date": business_date,
            "opened_by": user.get("label"),
        })
        if cfg.get("relay", {}).get("open_after_start", True):
            relay = set_relay_for_table(cfg, dst, True)
            if relay.get("ok"):
                dst_t["relay_on"] = True
    else:
        slot = next_player_slot(dst_t, dst, cfg)
        if not slot:
            return False, f"La table destination a déjà {allowed} joueurs.", None
        player["slot"] = slot
        player["id"] = make_player_id(dst, slot)
        dst_t.setdefault("players", []).append(player)
        normalize_player_slots_for_table(dst_t, dst, cfg)
        dst_t["max_players"] = max(int(dst_t.get("max_players") or 0), active_player_count(dst_t))

    normalize_player_slots_for_table(src_t, src, cfg)
    save_state(state)
    event("player_transfer", src, user, session_id=src_t.get("session_id"), player_id=player_id, to_table=dst)
    return True, "Joueur transféré.", enrich_state(state, cfg)


def transfer_table(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    src = int(payload.get("from_table"))
    dst = int(payload.get("to_table"))
    if src == dst:
        return False, "Même table.", None
    src_t = state["tables"].get(str(src))
    dst_t = state["tables"].get(str(dst))
    if not src_t or src_t.get("status") == "off":
        return False, "Table source inactive.", None
    if not dst_t:
        return False, "Table destination inconnue.", None
    if dst_t.get("status") != "off":
        return False, "La table destination est déjà ouverte.", None
    moved = json.loads(json.dumps(src_t, ensure_ascii=False))
    moved["number"] = dst
    moved.setdefault("transfer_history", []).append({"ts": utc_iso(), "from": src, "to": dst, "by": user.get("label")})
    for p in active_players_list(moved):
        old_id = str(p.get("id") or "")
        p.setdefault("previous_ids", [])
        if old_id and old_id not in p["previous_ids"]:
            p["previous_ids"].append(old_id)
    normalize_player_slots_for_table(moved, dst, cfg)
    moved["max_players"] = min(4, max(int(moved.get("max_players") or 0), active_player_count(moved)))
    state["tables"][str(dst)] = moved
    state["tables"][str(src)] = table_template(src)
    off = set_relay_for_table(cfg, src, False)
    on = set_relay_for_table(cfg, dst, True) if cfg.get("relay", {}).get("open_after_start", True) else {"ok": True, "message": "Relay not requested"}
    if on.get("ok"):
        state["tables"][str(dst)]["relay_on"] = True
    save_state(state)
    event("table_transfer", src, user, session_id=moved.get("session_id"), to_table=dst, relay_off=off, relay_on=on)
    return True, "Table transférée.", enrich_state(state, cfg)


def add_adjustment(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    t = state["tables"].get(str(table))
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    try:
        amount = float(payload.get("amount") or 0)
    except Exception:
        return False, "Montant invalide.", None
    row = {"ts": utc_iso(), "amount": amount, "note": str(payload.get("note") or "Ajustement"), "by": user.get("label")}
    t.setdefault("adjustments", []).append(row)
    save_state(state)
    event("table_adjustment", table, user, session_id=t.get("session_id"), amount=amount, note=row["note"])
    return True, "Ajustement ajouté.", enrich_state(state, cfg)


def stop_table(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    key = str(table)
    t = state["tables"].get(key)
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    now = time.time()
    if t.get("status") == "paused" and t.get("paused_at"):
        t["paused_total"] = float(t.get("paused_total") or 0) + max(0.0, now - float(t.get("paused_at")))
        t["paused_at"] = None
    duration = elapsed_seconds(t, now)
    totals = session_totals_for_table(t, cfg, now)
    original_total = float(totals["total"])
    prior_paid_total = float(totals["paid_total"])
    total_due = float(totals["due_total"])
    # Closed bills belong to the shift/date where the table was opened.
    # This prevents PM sessions closed after 03:00 from being misfiled as AM.
    fallback_shift_id, fallback_business_date = shift_for_ts(now)
    shift_id = str(t.get("shift_id") or fallback_shift_id)
    business_date = str(t.get("business_date") or fallback_business_date)
    participants = [p for p in active_players_list(t) if p.get("id") not in billed_player_ids_for_table(t)]
    if not participants:
        participants = [player_template(t.get("client") or "Joueur", table, 1)]
    per_player = money_round(total_due / max(1, len(participants)), float(cfg.get("rounding", 0.05)))
    total_without_tax = total_without_tax_from_total(total_due, cfg)
    tax_included = included_tax_from_total(total_due, cfg)
    player_bills = []
    for idx, p in enumerate(participants, 1):
        player_bills.append({
            "player_id": p.get("id"),
            "player_name": p.get("name") or f"Joueur {idx}",
            "bill_number": protected_number("PBILL", t.get("session_id"), p.get("id") or idx),
            "share_total": per_player,
            "share_total_without_tax": total_without_tax_from_total(per_player, cfg),
            "share_tax_included": included_tax_from_total(per_player, cfg),
        })
    row = {
        "session_id": t.get("session_id") or uuid.uuid4().hex,
        "parent_session_id": t.get("session_id"),
        "bill_type": "table_close",
        "bill_number": t.get("bill_number") or protected_number("BILL", local_dt(now).strftime("%Y%m%d"), table, uuid.uuid4().hex[:8]),
        "table": table,
        "client": t.get("client", ""),
        "players": participants,
        "player_bills": player_bills,
        "player_cashouts": t.get("player_cashouts") or [],
        "started_at": utc_iso(float(t.get("started_at") or now)),
        "ended_at": utc_iso(now),
        "local_date": local_date(now),
        "business_date": business_date,
        "shift_id": shift_id,
        "duration_seconds": int(duration),
        "pricing_id": t.get("pricing_id"),
        "pricing_name_fr": t.get("pricing_name_fr"),
        "pricing_name_en": t.get("pricing_name_en"),
        "pricing_kind": t.get("pricing_kind", "hourly"),
        "rate_per_hour": float(t.get("rate_per_hour") or 0),
        "flat_amount": float(t.get("flat_amount") or 0),
        "max_players": max(int(t.get("max_players") or 0), len(t.get("players") or []), 1),
        "extra_player_fee": float(t.get("extra_player_fee") or 0),
        "included_players": int(t.get("included_players") or 1),
        "adjustments": t.get("adjustments") or [],
        "subtotal": total_due,
        "tax": 0.0,
        "total_without_tax": total_without_tax,
        "tax_included": tax_included,
        "total": total_due,
        "original_session_total": original_total,
        "original_session_total_without_tax": total_without_tax_from_total(original_total, cfg),
        "original_session_tax_included": included_tax_from_total(original_total, cfg),
        "prior_paid_total": prior_paid_total,
        "currency": cfg.get("currency", "$"),
        "payment_method": str(payload.get("payment_method") or "cash"),
        "paid": bool(payload.get("paid", str(payload.get("payment_method") or "cash") != "unpaid")),
        "notes": t.get("notes", ""),
        "close_note": str(payload.get("note") or ""),
        "opened_by": t.get("opened_by"),
        "closed_by": user.get("label"),
    }
    append_jsonl(SESSIONS_PATH, row)
    relay = {"ok": True, "message": "Relay not requested"}
    if cfg.get("relay", {}).get("close_after_stop", True):
        relay = set_relay_for_table(cfg, table, False)
    state["tables"][key] = table_template(table)
    state["tables"][key]["last_total"] = original_total
    save_state(state)
    event("table_stop", table, user, session_id=row["session_id"], bill_number=row["bill_number"], total=total_due, original_session_total=original_total, prior_paid_total=prior_paid_total, payment_method=row["payment_method"], relay=relay)
    return True, "Table fermée et facture créée.", {"state": enrich_state(state, cfg), "receipt": row}


def cashout_player(payload: dict, user: dict) -> tuple[bool, str, dict | None]:
    cfg = load_config()
    state = load_state()
    table = int(payload.get("table"))
    key = str(table)
    player_id = str(payload.get("player_id") or "")
    payment_method = str(payload.get("payment_method") or "cash")
    t = state["tables"].get(key)
    if not t or t.get("status") == "off":
        return False, "Aucune session active.", None
    if player_id in billed_player_ids_for_table(t):
        return False, "Ce joueur a déjà été encaissé.", None
    player = None
    for p in t.get("players", []) or []:
        if str(p.get("id")) == player_id and p.get("active", True):
            player = p
            break
    if not player:
        return False, "Joueur actif introuvable.", None
    now = time.time()
    if t.get("status") == "paused" and t.get("paused_at"):
        # Keep paused state; only use current elapsed calculation. Do not change pause totals here.
        pass
    duration = elapsed_seconds(t, now)
    totals = session_totals_for_table(t, cfg, now)
    original_total = float(totals["total"])
    prior_paid_total = float(totals["paid_total"])
    remaining_before = money_round(max(0.0, original_total - prior_paid_total), float(cfg.get("rounding", 0.05)))
    active_before = active_player_count(t)
    allocations = player_running_allocations(t, cfg, now)
    if player_id in allocations:
        amount = float(allocations[player_id].get("running_total") or 0.0)
    else:
        share_count = billable_player_count(t)
        normal_share = money_round(original_total / max(1, share_count), float(cfg.get("rounding", 0.05)))
        amount = remaining_before if active_before <= 1 else min(normal_share, remaining_before)
    # If this is the last active player, collect the full remaining balance.
    if active_before <= 1:
        amount = remaining_before
    amount = money_round(amount, float(cfg.get("rounding", 0.05)))
    if amount <= 0:
        return False, "Aucun solde à encaisser pour ce joueur.", None
    shift_id = str(t.get("shift_id") or shift_for_ts(now)[0])
    business_date = str(t.get("business_date") or shift_for_ts(now)[1])
    bill_number = protected_number("PCASH", t.get("session_id"), player_id, uuid.uuid4().hex[:8])
    player_snapshot = json.loads(json.dumps(player, ensure_ascii=False))
    player_snapshot["active"] = False
    player_snapshot["cashed_out"] = True
    player_snapshot["cashed_out_at"] = utc_iso(now)
    player_snapshot["cashout_bill_number"] = bill_number
    player_bill = {
        "player_id": player_id,
        "player_name": player.get("name") or player_id,
        "bill_number": bill_number,
        "share_total": amount,
        "share_total_without_tax": total_without_tax_from_total(amount, cfg),
        "share_tax_included": included_tax_from_total(amount, cfg),
    }
    row = {
        "session_id": uuid.uuid4().hex,
        "parent_session_id": t.get("session_id"),
        "bill_type": "player_cashout",
        "bill_number": bill_number,
        "table": table,
        "client": player.get("name") or t.get("client", ""),
        "players": [player_snapshot],
        "player_bills": [player_bill],
        "player_id": player_id,
        "player_name": player.get("name") or player_id,
        "started_at": utc_iso(float(t.get("started_at") or now)),
        "ended_at": utc_iso(now),
        "local_date": local_date(now),
        "business_date": business_date,
        "shift_id": shift_id,
        "duration_seconds": int(duration),
        "pricing_id": t.get("pricing_id"),
        "pricing_name_fr": t.get("pricing_name_fr"),
        "pricing_name_en": t.get("pricing_name_en"),
        "pricing_kind": t.get("pricing_kind", "hourly"),
        "rate_per_hour": float(t.get("rate_per_hour") or 0),
        "flat_amount": float(t.get("flat_amount") or 0),
        "max_players": max(int(t.get("max_players") or 0), len(t.get("players") or []), 1),
        "extra_player_fee": float(t.get("extra_player_fee") or 0),
        "included_players": int(t.get("included_players") or 1),
        "adjustments": t.get("adjustments") or [],
        "subtotal": amount,
        "tax": 0.0,
        "total_without_tax": total_without_tax_from_total(amount, cfg),
        "tax_included": included_tax_from_total(amount, cfg),
        "total": amount,
        "original_session_total": original_total,
        "original_session_total_without_tax": total_without_tax_from_total(original_total, cfg),
        "original_session_tax_included": included_tax_from_total(original_total, cfg),
        "prior_paid_total": prior_paid_total,
        "remaining_total_after": money_round(max(0.0, original_total - prior_paid_total - amount), float(cfg.get("rounding", 0.05))),
        "currency": cfg.get("currency", "$"),
        "payment_method": payment_method,
        "paid": payment_method != "unpaid",
        "notes": t.get("notes", ""),
        "opened_by": t.get("opened_by"),
        "closed_by": user.get("label"),
    }
    append_jsonl(SESSIONS_PATH, row)
    t.setdefault("player_cashouts", []).append({
        "ts": utc_iso(now),
        "player_id": player_id,
        "player_name": player.get("name") or player_id,
        "bill_number": bill_number,
        "total": amount,
        "total_without_tax": row["total_without_tax"],
        "tax_included": row["tax_included"],
        "payment_method": payment_method,
        "paid": payment_method != "unpaid",
    })
    for p in t.get("players", []) or []:
        if str(p.get("id")) == player_id:
            p["active"] = False
            p["removed_at"] = utc_iso(now)
            p["remove_reason"] = "Encaissé"
            p["cashed_out"] = True
            p["cashed_out_at"] = utc_iso(now)
            p["cashout_bill_number"] = bill_number
            p["cashout_total"] = amount
            p["cashout_without_tax"] = row["total_without_tax"]
            p["cashout_tax_included"] = row["tax_included"]
            p["running_total"] = 0.0
            break
    relay = {"ok": True, "message": "Relay not requested"}
    if active_player_count(t) <= 0:
        if cfg.get("relay", {}).get("close_after_stop", True):
            relay = set_relay_for_table(cfg, table, False)
        state["tables"][key] = table_template(table)
        state["tables"][key]["last_total"] = original_total
        event("table_auto_closed_after_player_cashouts", table, user, parent_session_id=t.get("session_id"), relay=relay, original_session_total=original_total)
    save_state(state)
    event("player_cashout", table, user, parent_session_id=t.get("session_id"), player_id=player_id, bill_number=bill_number, total=amount, original_session_total=original_total, remaining=row["remaining_total_after"], payment_method=payment_method)
    return True, "Joueur encaissé.", {"state": enrich_state(state, cfg), "receipt": row}


def relay_action(payload: dict, user: dict) -> dict:
    cfg = load_config()
    state = load_state()
    table = payload.get("table")
    channel = payload.get("channel")
    on = bool(payload.get("on"))
    if table not in (None, ""):
        table = int(table)
        channel = int(get_table_config(cfg, table).get("relay_channel"))
    else:
        channel = int(channel)
        table = None
    res = RelayDriver(cfg).send(channel, on)
    if table is not None and str(table) in state.get("tables", {}):
        if res.get("ok"):
            state["tables"][str(table)]["relay_on"] = on
            save_state(state)
        event("relay_manual", table, user, channel=channel, on=on, relay=res)
    else:
        event("relay_test", None, user, channel=channel, on=on, relay=res)
    return res


def set_all_table_relays(payload: dict, user: dict) -> dict:
    cfg = load_config()
    state = load_state()
    on = bool(payload.get("on"))
    results = []
    driver = RelayDriver(cfg)
    for tc in cfg.get("tables", []):
        if not bool(tc.get("enabled", True)):
            continue
        ch = int(tc.get("relay_channel"))
        res = driver.send(ch, on)
        results.append({"table": tc.get("number"), "channel": ch, **res})
        if res.get("ok") and str(tc.get("number")) in state.get("tables", {}):
            state["tables"][str(tc.get("number"))]["relay_on"] = on
    save_state(state)
    event("relay_all_tables", None, user, on=on, results=results)
    return {"ok": True, "results": results, "state": enrich_state(state, cfg)}


def sessions_filtered(date: str | None = None, shift: str | None = None, pricing_id: str | None = None, pricing_kind: str | None = None, from_date: str | None = None, to_date: str | None = None, text: str | None = None) -> list[dict]:
    rows = read_jsonl(SESSIONS_PATH)
    d = parse_date(date)
    fd = parse_date(from_date)
    td = parse_date(to_date)
    out = []
    for r in rows:
        bdate = parse_date(r.get("business_date") or r.get("local_date"))
        if d and bdate != d:
            continue
        if fd and (not bdate or bdate < fd):
            continue
        if td and (not bdate or bdate > td):
            continue
        if shift and shift != "all" and str(r.get("shift_id")) != shift:
            continue
        if pricing_id and pricing_id != "all" and str(r.get("pricing_id")) != pricing_id:
            continue
        if pricing_kind and pricing_kind != "all" and str(r.get("pricing_kind")) != pricing_kind:
            continue
        if text:
            hay = json.dumps(r, ensure_ascii=False).lower()
            if text.lower() not in hay:
                continue
        out.append(r)
    out.sort(key=lambda x: x.get("ended_at") or "")
    return out


def summarize_sessions(rows: list[dict], cfg: dict | None = None) -> dict:
    cfg = load_config() if cfg is None else cfg
    table_totals: dict[str, float] = {}
    pricing_totals: dict[str, float] = {}
    shift_totals: dict[str, float] = {}
    total = 0.0
    total_without_tax = 0.0
    tax_included = 0.0
    for r in rows:
        val = float(r.get("total") or 0.0)
        total += val
        wt = float(r.get("total_without_tax") if r.get("total_without_tax") is not None else total_without_tax_from_total(val, cfg))
        ti = float(r.get("tax_included") if r.get("tax_included") is not None else included_tax_from_total(val, cfg))
        total_without_tax += wt
        tax_included += ti
        table_totals[str(r.get("table"))] = table_totals.get(str(r.get("table")), 0.0) + val
        pricing_totals[str(r.get("pricing_id"))] = pricing_totals.get(str(r.get("pricing_id")), 0.0) + val
        shift_totals[str(r.get("shift_id"))] = shift_totals.get(str(r.get("shift_id")), 0.0) + val
    return {
        "count": len(rows),
        "total": money_round(total, float(cfg.get("rounding", 0.05))),
        "total_without_tax": round(total_without_tax, 2),
        "tax_included": round(tax_included, 2),
        "table_totals": {k: money_round(v, float(cfg.get("rounding", 0.05))) for k, v in sorted(table_totals.items())},
        "pricing_totals": {k: money_round(v, float(cfg.get("rounding", 0.05))) for k, v in sorted(pricing_totals.items())},
        "shift_totals": {k: money_round(v, float(cfg.get("rounding", 0.05))) for k, v in sorted(shift_totals.items())},
    }


def shift_report(date: str, shift: str) -> dict:
    cfg = load_config()
    rows = sessions_filtered(date=date, shift=shift)
    return {
        "ok": True,
        "type": "shift",
        "date": date,
        "shift": shift,
        "report_number": protected_number("SHIFT", date.replace("-", ""), shift.upper()),
        "summary": summarize_sessions(rows, cfg),
        "sessions": rows,
    }


def daily_report(date: str) -> dict:
    cfg = load_config()
    rows = sessions_filtered(date=date)
    return {
        "ok": True,
        "type": "daily",
        "date": date,
        "report_number": protected_number("DAY", date.replace("-", "")),
        "summary": summarize_sessions(rows, cfg),
        "sessions": rows,
    }


def close_report_shift_for_user(user: dict | None = None) -> tuple[str, str]:
    """Use the signed-in staff shift for drawer closing.

    This is deterministic: AM password closes AM, PM password closes PM, even if the
    current computer time rolls over near shift boundaries. Admin uses the live shift.
    """
    if user and user.get("role") == "staff" and user.get("shift") in ("am", "pm"):
        return str(user.get("shift")), str(user.get("business_date") or current_shift()[1])
    return current_shift()


def active_table_snapshots() -> list[dict]:
    state = enrich_state()
    rows = []
    for t in sorted(state.get("state", {}).get("tables", {}).values(), key=lambda x: int(x.get("number", 0))):
        if t.get("status") != "off":
            rows.append({
                "table": int(t.get("number") or 0),
                "status": t.get("status"),
                "total": float(t.get("total") or 0.0),
                "total_without_tax": float(t.get("total_without_tax") or 0.0),
                "tax_included": float(t.get("tax_included") or 0.0),
                "elapsed_seconds": int(t.get("elapsed_seconds") or 0),
                "players": int(t.get("active_players") or 0),
            })
    return rows


def close_report_preview(user: dict | None = None) -> dict:
    shift_id, business_date = close_report_shift_for_user(user)
    srep = shift_report(business_date, shift_id)
    active = active_table_snapshots()
    return {
        "ok": True,
        "type": "close_report_preview",
        "shift": shift_id,
        "business_date": business_date,
        "can_close": len(active) == 0,
        "active_tables": active,
        "shift_report": srep,
    }


def close_shift_with_report(user: dict | None = None) -> dict:
    preview = close_report_preview(user)
    if preview.get("active_tables"):
        raise ValueError("Fermez toutes les tables avant de fermer le quart.")
    s = preview.get("shift_report", {}).get("summary", {})
    event(
        "shift_close_report",
        None,
        user or {"role": "system"},
        shift=preview.get("shift"),
        business_date=preview.get("business_date"),
        shift_report_number=preview.get("shift_report", {}).get("report_number"),
        shift_total=s.get("total", 0),
        shift_total_without_tax=s.get("total_without_tax", 0),
        shift_tax_included=s.get("tax_included", 0),
        shift_session_count=s.get("count", 0),
    )
    preview["closed"] = True
    return preview


def owner_report(query: dict) -> dict:
    cfg = load_config()
    rows = sessions_filtered(
        from_date=query.get("from"),
        to_date=query.get("to"),
        shift=query.get("shift"),
        pricing_id=query.get("pricing_id"),
        pricing_kind=query.get("pricing_kind"),
        text=query.get("text"),
    )
    dates = sorted({r.get("business_date") or r.get("local_date") for r in rows if r.get("business_date") or r.get("local_date")})
    daily_catalog = [{"date": d, "report_number": protected_number("DAY", str(d).replace("-", "")), "total": summarize_sessions(sessions_filtered(date=d), cfg)["total"]} for d in dates]
    shift_catalog = []
    for d in dates:
        for sh in ("am", "pm"):
            sh_rows = sessions_filtered(date=d, shift=sh)
            if sh_rows:
                shift_catalog.append({"date": d, "shift": sh, "report_number": protected_number("SHIFT", str(d).replace("-", ""), sh.upper()), "total": summarize_sessions(sh_rows, cfg)["total"]})
    return {
        "ok": True,
        "type": "owner",
        "report_number": protected_number("OWNER", query.get("from") or "start", query.get("to") or "now", query.get("pricing_id") or "all", query.get("pricing_kind") or "all"),
        "filters": query,
        "summary": summarize_sessions(rows, cfg),
        "daily_catalog": daily_catalog,
        "shift_catalog": shift_catalog,
        "report_catalog": [
            *[{"type": "daily", **x} for x in daily_catalog],
            *[{"type": "shift", **x} for x in shift_catalog],
        ],
        "sessions": rows,
    }


def active_bill(table: int) -> dict:
    cfg = load_config()
    state = load_state()
    t = state.get("tables", {}).get(str(table))
    if not t or t.get("status") == "off":
        raise ValueError("Aucune session active.")
    now = time.time()
    totals = session_totals_for_table(t, cfg, now)
    original_total = float(totals["total"])
    paid_total = float(totals["paid_total"])
    due_total = float(totals["due_total"])
    participants = [p for p in active_players_list(t) if p.get("id") not in billed_player_ids_for_table(t)]
    if not participants:
        participants = [player_template(t.get("client") or "Joueur 1", table, 1)]
    per_player = money_round(due_total / max(1, len(participants)), float(cfg.get("rounding", 0.05)))
    return {
        "session_id": t.get("session_id"),
        "bill_number": t.get("bill_number") or protected_number("PREBILL", table, int(now)),
        "preview": True,
        "bill_type": "active_preview",
        "table": table,
        "client": t.get("client", ""),
        "players": participants,
        "player_cashouts": t.get("player_cashouts") or [],
        "player_bills": [{"player_id": p.get("id"), "player_name": p.get("name"), "bill_number": protected_number("PPRE", t.get("session_id"), p.get("id")), "share_total": per_player, "share_total_without_tax": total_without_tax_from_total(per_player, cfg), "share_tax_included": included_tax_from_total(per_player, cfg)} for p in participants],
        "started_at": utc_iso(float(t.get("started_at") or now)),
        "ended_at": utc_iso(now),
        "duration_seconds": int(elapsed_seconds(t, now)),
        "pricing_id": t.get("pricing_id"),
        "pricing_name_fr": t.get("pricing_name_fr"),
        "pricing_name_en": t.get("pricing_name_en"),
        "pricing_kind": t.get("pricing_kind"),
        "rate_per_hour": float(t.get("rate_per_hour") or 0),
        "flat_amount": float(t.get("flat_amount") or 0),
        "max_players": max(int(t.get("max_players") or 0), len(t.get("players") or []), 1),
        "extra_player_fee": float(t.get("extra_player_fee") or 0),
        "included_players": int(t.get("included_players") or 1),
        "adjustments": t.get("adjustments") or [],
        "subtotal": due_total,
        "tax": 0.0,
        "total_without_tax": total_without_tax_from_total(due_total, cfg),
        "tax_included": included_tax_from_total(due_total, cfg),
        "total": due_total,
        "original_session_total": original_total,
        "original_session_total_without_tax": total_without_tax_from_total(original_total, cfg),
        "original_session_tax_included": included_tax_from_total(original_total, cfg),
        "prior_paid_total": paid_total,
        "paid": False,
        "notes": t.get("notes", ""),
    }


def find_session(session_id: str) -> dict | None:
    for r in read_jsonl(SESSIONS_PATH):
        if str(r.get("session_id")) == str(session_id):
            return r
    return None


def duration_text(seconds: int | float) -> str:
    seconds = int(seconds or 0)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    return f"{h}h {m:02d}m"


def _pdf_hex_text(text: object) -> str:
    safe = str(text).replace("\t", "    ").replace("\r", "")
    data = ("\ufeff" + safe).encode("utf-16-be", errors="replace")
    return "<" + data.hex().upper() + ">"


def _wrap_pdf_line(text: object, width: int = 92) -> list[str]:
    raw = str(text)
    if raw == "":
        return [""]
    out: list[str] = []
    for part in raw.split("\n"):
        words = part.split(" ")
        line = ""
        for word in words:
            candidate = word if not line else line + " " + word
            if len(candidate) <= width:
                line = candidate
            else:
                if line:
                    out.append(line)
                while len(word) > width:
                    out.append(word[:width])
                    word = word[width:]
                line = word
        out.append(line)
    return out or [""]


def _amount_line(left: object, right: object, width: int = 92) -> str:
    left_s = str(left)
    right_s = str(right)
    room = max(10, width - len(right_s) - 2)
    if len(left_s) > room:
        left_s = left_s[: room - 1] + "…"
    return f"{left_s:<{room}}  {right_s:>{len(right_s)}}"


def _simple_pdf(title: str, lines: list[object]) -> bytes:
    """Small built-in PDF writer. No external libraries required."""
    page_width, page_height = 612, 792
    x, y_start, y_min = 48, 750, 54
    normalized: list[tuple[str, int, bool]] = [(title, 16, True)]
    normalized.append(("=" * min(70, max(10, len(title))), 10, False))
    for item in lines:
        if isinstance(item, tuple):
            txt, size, bold = item
            for part in _wrap_pdf_line(txt, 90 if int(size) <= 10 else 70):
                normalized.append((part, int(size), bool(bold)))
        else:
            for part in _wrap_pdf_line(item, 92):
                normalized.append((part, 10, False))

    pages: list[list[tuple[str, int, bool]]] = []
    current: list[tuple[str, int, bool]] = []
    y = y_start
    for text, size, bold in normalized:
        leading = max(12, int(size) + 4)
        if y - leading < y_min and current:
            pages.append(current)
            current = []
            y = y_start
        current.append((text, size, bold))
        y -= leading
    if current:
        pages.append(current)

    page_ids = [6 + i * 2 for i in range(len(pages))]
    kids = " ".join(f"{pid} 0 R" for pid in page_ids)
    objects: list[bytes] = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        f"<< /Type /Pages /Count {len(pages)} /Kids [{kids}] >>".encode("ascii"),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    ]

    for page_index, page in enumerate(pages):
        ops = ["q", "BT"]
        y = y_start
        for text, size, bold in page:
            leading = max(12, int(size) + 4)
            font = "/F2" if bold else "/F1"
            ops.append(f"{font} {int(size)} Tf")
            ops.append(f"1 0 0 1 {x} {y} Tm")
            ops.append(_pdf_hex_text(text) + " Tj")
            y -= leading
        ops.extend(["ET", "Q"])
        stream = "\n".join(ops).encode("ascii")
        content_obj = b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream"
        content_id = 5 + page_index * 2
        page_id = 6 + page_index * 2
        page_obj = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {page_width} {page_height}] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {content_id} 0 R >>"
        ).encode("ascii")
        objects.append(content_obj)
        objects.append(page_obj)

    pdf = bytearray(b"%PDF-1.4\n%\xE2\xE3\xCF\xD3\n")
    offsets = [0]
    for idx, obj in enumerate(objects, 1):
        offsets.append(len(pdf))
        pdf.extend(f"{idx} 0 obj\n".encode("ascii"))
        pdf.extend(obj)
        pdf.extend(b"\nendobj\n")
    xref_pos = len(pdf)
    pdf.extend(f"xref\n0 {len(objects)+1}\n".encode("ascii"))
    pdf.extend(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        pdf.extend(f"{off:010d} 00000 n \n".encode("ascii"))
    pdf.extend(f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n".encode("ascii"))
    return bytes(pdf)


def pdf_receipt(row: dict, player_id: str | None = None) -> bytes:
    cfg = load_config()
    player_bill = None
    if player_id:
        for p in row.get("player_bills", []):
            if str(p.get("player_id")) == str(player_id):
                player_bill = p
                break
    is_player = bool(player_id)
    title = "FACTURE JOUEUR" if is_player else "FACTURE TABLE"
    number = player_bill.get("bill_number") if player_bill else row.get("bill_number")
    lines: list[object] = []
    lines.append((str(cfg.get("business_name", "Billard")), 14, True))
    lines.append(f"Numéro protégé: {number}")
    if row.get("preview"):
        lines.append("PREFACTURE - session encore active")
    lines.append("")
    lines.append(_amount_line("Table", row.get("table", "")))
    lines.append(_amount_line("Client", row.get("client", "")))
    lines.append(_amount_line("Début", row.get("started_at", "")))
    lines.append(_amount_line("Fin", row.get("ended_at", "")))
    lines.append(_amount_line("Durée", duration_text(row.get("duration_seconds", 0))))
    lines.append(_amount_line("Tarif", row.get("pricing_name_fr") or row.get("pricing_id") or ""))
    lines.append(_amount_line("Structure", row.get("pricing_kind") or ""))
    lines.append("")
    lines.append(("DÉTAILS", 12, True))
    if row.get("pricing_kind") == "flat":
        lines.append(_amount_line("Forfait", money(float(row.get("flat_amount") or 0), cfg)))
    else:
        hours = float(row.get("duration_seconds") or 0) / 3600.0
        lines.append(_amount_line(f"Temps de table @ {money(float(row.get('rate_per_hour') or 0), cfg)}/h ({hours:.2f} h)", money(hours * float(row.get("rate_per_hour") or 0), cfg)))
    extra_players = max(0, int(row.get("max_players") or 1) - int(row.get("included_players") or 1))
    if extra_players and float(row.get("extra_player_fee") or 0):
        lines.append(_amount_line(f"Joueurs extra x{extra_players}", money(extra_players * float(row.get("extra_player_fee") or 0), cfg)))
    for a in row.get("adjustments") or []:
        lines.append(_amount_line(str(a.get("note") or "Ajustement"), money(float(a.get("amount") or 0), cfg)))
    lines.append("-" * 92)
    total_value = float(row.get("total") or 0)
    no_tax_value = float(row.get("total_without_tax") if row.get("total_without_tax") is not None else total_without_tax_from_total(total_value, cfg))
    included_tax_value = float(row.get("tax_included") if row.get("tax_included") is not None else included_tax_from_total(total_value, cfg))
    lines.append(_amount_line("Total sans taxes (total / 1.15)", money(no_tax_value, cfg)))
    lines.append(_amount_line("Taxes incluses", money(included_tax_value, cfg)))
    if row.get("original_session_total") is not None and float(row.get("original_session_total") or 0) != total_value:
        lines.append(_amount_line("TOTAL SESSION COMPLÈTE", money(float(row.get("original_session_total") or 0), cfg)))
        lines.append(_amount_line("Déjà encaissé", money(float(row.get("prior_paid_total") or 0), cfg)))
        lines.append(_amount_line("TOTAL À ENCAISSER", money(total_value, cfg)))
    else:
        lines.append(_amount_line("TOTAL SESSION", money(total_value, cfg)))
    if player_bill:
        lines.append(_amount_line(f"PART DE {player_bill.get('player_name')}", money(float(player_bill.get("share_total") or 0), cfg)))
        lines.append(_amount_line("Part sans taxes (part / 1.15)", money(float(player_bill.get("share_total_without_tax") or total_without_tax_from_total(float(player_bill.get("share_total") or 0), cfg)), cfg)))
        lines.append(_amount_line("Taxes incluses sur la part", money(float(player_bill.get("share_tax_included") or included_tax_from_total(float(player_bill.get("share_total") or 0), cfg)), cfg)))
    lines.append("")
    lines.append(("JOUEURS", 12, True))
    for p in row.get("players") or []:
        status = "actif" if p.get("active", True) else "retiré"
        extra = f" -> table {p.get('transferred_to_table')}" if p.get("transferred_to_table") else ""
        lines.append(f"- {p.get('id') or ''} | {p.get('name') or ''} [{status}]{extra}")
    lines.append("")
    lines.append("Document généré localement par SayF Pool Control.")
    return _simple_pdf(f"{title} - {number}", lines)


def pdf_report(rep: dict) -> bytes:
    cfg = load_config()
    title_map = {"shift": "RAPPORT DE QUART", "daily": "RAPPORT JOURNALIER", "owner": "RAPPORT PROPRIÉTAIRE"}
    title = f"{title_map.get(rep.get('type'), 'RAPPORT')} - {rep.get('report_number')}"
    summ = rep.get("summary", {})
    lines: list[object] = []
    lines.append((str(cfg.get("business_name", "Billard")), 14, True))
    lines.append(f"Généré: {utc_iso()} | Version: {APP_VERSION}")
    if rep.get("date"):
        lines.append(_amount_line("Date", rep.get("date")))
    if rep.get("shift"):
        lines.append(_amount_line("Quart", str(rep.get("shift")).upper()))
    lines.append(_amount_line("Sessions", summ.get("count", 0)))
    lines.append(_amount_line("Total", money(float(summ.get("total") or 0), cfg)))
    lines.append(_amount_line("Total sans taxes (total / 1.15)", money(float(summ.get("total_without_tax") or 0), cfg)))
    lines.append(_amount_line("Taxes incluses", money(float(summ.get("tax_included") or 0), cfg)))
    lines.append("")
    table_totals = summ.get("table_totals") or {}
    if table_totals:
        lines.append(("TOTAL PAR TABLE", 12, True))
        for k, v in table_totals.items():
            lines.append(_amount_line(f"Table {k}", money(float(v), cfg)))
        lines.append("")
    pricing_totals = summ.get("pricing_totals") or {}
    if pricing_totals:
        lines.append(("TOTAL PAR TARIF", 12, True))
        for k, v in pricing_totals.items():
            lines.append(_amount_line(str(k), money(float(v), cfg)))
        lines.append("")
    if rep.get("type") == "owner":
        lines.append(("CATALOGUE DES RAPPORTS", 12, True))
        for d in rep.get("daily_catalog", []):
            lines.append(_amount_line(f"Jour {d.get('date')} | {d.get('report_number')}", money(float(d.get("total") or 0), cfg)))
        for srow in rep.get("shift_catalog", []):
            lines.append(_amount_line(f"Quart {srow.get('date')} {str(srow.get('shift')).upper()} | {srow.get('report_number')}", money(float(srow.get("total") or 0), cfg)))
        lines.append("")
        lines.append("Filtres: " + json.dumps(rep.get("filters") or {}, ensure_ascii=False))
        lines.append("")
    lines.append(("FACTURES", 12, True))
    for r in (rep.get("sessions") or [])[:300]:
        label = f"{r.get('bill_number')} | {r.get('business_date') or r.get('local_date')} | {str(r.get('shift_id') or '').upper()} | Table {r.get('table')} | {r.get('pricing_id')} | {r.get('pricing_kind')}"
        lines.append(_amount_line(label, money(float(r.get("total") or 0), cfg)))
    lines.append("")
    lines.append(f"Numéro protégé: {rep.get('report_number')}")
    return _simple_pdf(title, lines)

def backup_now() -> dict:
    stamp = local_dt().strftime("%Y%m%d_%H%M%S")
    folder = BACKUP_DIR / stamp
    folder.mkdir(parents=True, exist_ok=True)
    for p in (CONFIG_PATH, STATE_PATH, SESSIONS_PATH, EVENTS_PATH, RELAY_LOG_PATH):
        if p.exists():
            shutil.copy2(p, folder / p.name)
    return {"ok": True, "folder": str(folder)}


def csv_sessions(rows: list[dict] | None = None) -> str:
    rows = read_jsonl(SESSIONS_PATH) if rows is None else rows
    buf = io.StringIO()
    fields = ["bill_number", "business_date", "shift_id", "table", "client", "pricing_id", "pricing_kind", "duration_seconds", "max_players", "subtotal", "tax", "total_without_tax", "tax_included", "total", "payment_method", "paid", "started_at", "ended_at"]
    writer = csv.DictWriter(buf, fieldnames=fields)
    writer.writeheader()
    for r in rows:
        writer.writerow({k: r.get(k, "") for k in fields})
    return buf.getvalue()


HTML = r'''<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SayF Pool Control</title>
<style>
:root{--bg:#08110d;--panel:#101b15;--panel2:#14251c;--line:#284434;--text:#f4fff8;--muted:#9fb9aa;--accent:#33d17a;--danger:#ff5f57;--warn:#ffd166;--blue:#66b3ff;--shadow:rgba(0,0,0,.35)}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#050806,#102117 60%,#09110d);color:var(--text);font-family:Arial,Helvetica,sans-serif}button,input,select,textarea{font:inherit}button{cursor:pointer;border:0;border-radius:12px;padding:10px 12px;background:#223a2c;color:var(--text);box-shadow:0 6px 14px var(--shadow)}button:hover{filter:brightness(1.15)}button.primary{background:var(--accent);color:#031007;font-weight:800}button.danger{background:var(--danger);color:white}button.warn{background:var(--warn);color:#1d1600}button.blue{background:var(--blue);color:#04111f}button.ghost{background:transparent;border:1px solid var(--line);box-shadow:none}button:disabled{opacity:.35;cursor:not-allowed}input,select,textarea{width:100%;border:1px solid var(--line);background:#07120d;color:var(--text);border-radius:10px;padding:9px}label{font-size:12px;color:var(--muted);display:block;margin-bottom:5px}.app{min-height:100vh}.top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid var(--line);background:rgba(8,17,13,.88);position:sticky;top:0;z-index:10;backdrop-filter:blur(10px)}.brand{display:flex;flex-direction:column}.brand b{font-size:21px}.brand span{font-size:12px;color:var(--muted)}.actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.badge{padding:7px 10px;border:1px solid var(--line);border-radius:999px;background:#0e1c14;color:var(--muted)}.wrap{padding:18px;max-width:1500px;margin:0 auto}.tabs{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap}.tab{background:#13231a}.tab.active{background:var(--accent);color:#031007;font-weight:800}.grid{display:grid;grid-template-columns:repeat(3,minmax(280px,1fr));gap:14px}.card{background:linear-gradient(180deg,var(--panel),#0b1510);border:1px solid var(--line);border-radius:18px;padding:14px;box-shadow:0 12px 24px var(--shadow)}.card.on{border-color:var(--accent)}.card.paused{border-color:var(--warn)}.row{display:grid;grid-template-columns:repeat(12,1fr);gap:10px}.col-2{grid-column:span 2}.col-3{grid-column:span 3}.col-4{grid-column:span 4}.col-5{grid-column:span 5}.col-6{grid-column:span 6}.col-8{grid-column:span 8}.col-12{grid-column:span 12}.titleline{display:flex;align-items:flex-start;justify-content:space-between;gap:8px}.big{font-size:27px;font-weight:900}.money{font-size:28px;font-weight:900;color:var(--accent)}.muted{color:var(--muted)}.tiny{font-size:12px;color:var(--muted)}.status{font-size:12px;text-transform:uppercase;letter-spacing:.08em;padding:6px 8px;border-radius:999px;background:#1a2c22;color:var(--muted)}.status.running{background:rgba(51,209,122,.16);color:var(--accent)}.status.paused{background:rgba(255,209,102,.16);color:var(--warn)}.players{display:flex;flex-direction:column;gap:7px;margin:10px 0}.player{display:grid;grid-template-columns:1fr auto auto auto;gap:6px;align-items:center;background:#07120d;border:1px solid var(--line);border-radius:12px;padding:8px}.player.off{opacity:.5;text-decoration:line-through}.btns{display:flex;gap:7px;flex-wrap:wrap}.pricebtns{display:flex;gap:7px;flex-wrap:wrap;margin:7px 0}.pricebtns button.active{outline:3px solid #fff;box-shadow:0 0 0 3px rgba(51,209,122,.45)}.pricebtns button.rate-available{background:var(--accent);color:#031007;font-weight:900}.pricebtns button.rate-unavailable{background:#3b4540;color:#aeb8b1;box-shadow:none}.pricebtns button.rate-unavailable:disabled{opacity:1}.pricehint{font-size:12px;color:var(--muted);margin-top:4px}.login{max-width:480px;margin:9vh auto;padding:28px;border-radius:22px;background:var(--panel);border:1px solid var(--line);box-shadow:0 20px 60px var(--shadow)}.login h1{margin-top:0}.toast{position:fixed;right:18px;bottom:18px;padding:13px 16px;border-radius:14px;background:#10291a;border:1px solid var(--accent);display:none;z-index:99;max-width:420px}.toast.err{border-color:var(--danger);background:#2b1111}.tablewrap{overflow:auto;border:1px solid var(--line);border-radius:14px}.report-table{width:100%;border-collapse:collapse;background:#07120d}.report-table th,.report-table td{border-bottom:1px solid var(--line);padding:9px;text-align:left;font-size:13px}.report-table th{background:#14251c;color:var(--muted);position:sticky;top:0}.modal{position:fixed;inset:0;background:rgba(0,0,0,.72);display:none;z-index:50;align-items:center;justify-content:center;padding:20px}.modal .box{background:#f8fff9;color:#07120d;width:min(850px,96vw);max-height:92vh;overflow:auto;border-radius:14px;padding:24px}.invoice{font-family:Arial,Helvetica,sans-serif}.invoice h2{margin:0 0 4px}.invoice .line{display:flex;justify-content:space-between;border-bottom:1px solid #ddd;padding:8px 0}.invoice table{width:100%;border-collapse:collapse;margin-top:14px}.invoice th,.invoice td{border:1px solid #ddd;padding:8px}.invoice th{background:#111;color:white}.invoice .total{font-size:24px;font-weight:900;text-align:right}.closex{float:right;background:#111;color:white}.split{display:grid;grid-template-columns:1.1fr .9fr;gap:14px}.kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.kpi div{background:#07120d;border:1px solid var(--line);border-radius:14px;padding:12px}.kpi b{display:block;font-size:22px;color:var(--accent)}@media(max-width:1050px){.grid{grid-template-columns:repeat(2,minmax(260px,1fr))}.split{grid-template-columns:1fr}.kpi{grid-template-columns:repeat(2,1fr)}}@media(max-width:720px){.grid{grid-template-columns:1fr}.row{grid-template-columns:1fr}.col-2,.col-3,.col-4,.col-5,.col-6,.col-8,.col-12{grid-column:span 1}.top{align-items:flex-start}.actions{justify-content:flex-end}.player{grid-template-columns:1fr 1fr}.money{font-size:22px}}@media print{body{background:white;color:black}.top,.tabs,.btns,.actions,.toast{display:none}.card{box-shadow:none;border:1px solid #ccc;color:black;background:white}.modal{position:static;display:block;background:white}.modal .box{box-shadow:none;max-height:none}.closex{display:none}}

/* Tablet-native touch layer */
button{min-height:44px;touch-action:manipulation}input,select{min-height:44px}.slotid{display:inline-block;min-width:54px;text-align:center;background:#1d3a2a;border:1px solid var(--accent);border-radius:999px;color:var(--accent);font-weight:900;padding:7px 9px}.no-tax{color:var(--muted);font-size:13px;margin-top:3px}.closegrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.closegrid .full{grid-column:1/-1}.customBox{border:1px dashed var(--warn);border-radius:12px;padding:8px;margin:7px 0;background:rgba(255,209,102,.08)}@media(pointer:coarse){button{min-height:52px;padding:14px 16px}input,select{min-height:52px;font-size:18px}.tabs button{flex:1}.pricebtns button{flex:1 1 45%}.btns button{flex:1 1 45%}.grid{grid-template-columns:repeat(2,minmax(300px,1fr))}}@media(max-width:850px){.grid{grid-template-columns:1fr}.closegrid{grid-template-columns:1fr}}

/* V7 slot multi-select transfer */
.slotTransfer{border:1px solid var(--line);background:rgba(7,18,13,.72);border-radius:14px;padding:10px;margin:10px 0}.slotTransferTop{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:8px}.slotBtns{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.slotbtn{min-height:62px;border:1px solid var(--line);background:#101b15;box-shadow:none;text-align:center;padding:8px}.slotbtn.live{border-color:var(--accent);color:var(--accent)}.slotbtn.empty{background:#27332d;color:#839287;border-color:#3a4a41}.slotbtn.selected{background:var(--accent);color:#031007;outline:3px solid #fff;font-weight:900}.slotbtn small{display:block;font-size:10px;opacity:.8;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.transferControls{display:grid;grid-template-columns:1fr auto;gap:8px;margin-top:8px}.playerEdit{display:grid;grid-template-columns:auto 1fr auto auto auto auto;gap:8px;align-items:center;background:#07120d;border:1px solid var(--line);border-radius:12px;padding:8px}.playerEdit.off{opacity:.5;text-decoration:line-through}@media(pointer:coarse){.slotbtn{min-height:72px;font-size:18px}.transferControls{grid-template-columns:1fr}.playerEdit{grid-template-columns:1fr 1fr}.slotid{width:100%}}@media(max-width:720px){.slotBtns{grid-template-columns:repeat(2,1fr)}.transferControls{grid-template-columns:1fr}.playerEdit{grid-template-columns:1fr}}.startSlotsBox{border:1px solid var(--line);border-radius:14px;padding:10px;margin:8px 0;background:#07120d}.startSlotsBox .slotbtn.selected{background:var(--accent);color:#031007;outline:3px solid #fff}.slotTransfer .slotbtn{touch-action:manipulation}.oldTransferGone{display:none!important}.playerTotal{min-width:118px;border:1px solid var(--line);border-radius:12px;padding:7px 9px;background:#0b1b12;text-align:right}.playerTotal b{display:block;color:var(--accent);font-size:16px}.playerTotal small{display:block;color:var(--muted);font-size:10px;line-height:1.2}.playerTotal.paid{background:rgba(51,209,122,.14);border-color:var(--accent)}.playerTotal.paid b{color:var(--accent)}

/* V12 physical table-map + fluid tablet layout
   Real floor map on wide screens:
   top:    4 | 6 | 8
   bottom: 3 | 5 | 7
*/
.wrap{width:100%;max-width:min(100vw,1800px);padding:clamp(8px,1.15vw,18px)}
.floorGrid{grid-template-columns:repeat(3,minmax(210px,1fr));grid-template-areas:"t4 t6 t8" "t3 t5 t7";gap:clamp(8px,1vw,14px);align-items:start;width:100%}
.floorGrid .table-3{grid-area:t3}.floorGrid .table-4{grid-area:t4}.floorGrid .table-5{grid-area:t5}.floorGrid .table-6{grid-area:t6}.floorGrid .table-7{grid-area:t7}.floorGrid .table-8{grid-area:t8}
.tableCard{min-width:0;overflow:hidden}.tableCard .titleline{min-width:0}.tableCard .big{font-size:clamp(20px,2vw,27px);line-height:1.05}.tableCard .money{font-size:clamp(21px,2.3vw,28px);line-height:1.05}.tableCard input,.tableCard select,.tableCard button{max-width:100%}.tableCard .btns button,.tableCard .pricebtns button,.tableCard .closegrid button{white-space:normal}.top{padding:clamp(8px,1vw,14px) clamp(10px,1.2vw,18px)}.tabs{margin-bottom:clamp(8px,1vw,16px)}
@media(max-width:1180px){.floorGrid{grid-template-columns:repeat(3,minmax(190px,1fr));gap:10px}.card{padding:10px;border-radius:16px}.slotbtn{min-height:56px}.players{gap:6px}.playerEdit{gap:6px;padding:7px}.no-tax,.tiny{font-size:11px}.pricebtns{gap:6px}.btns{gap:6px}}
@media(max-width:900px){.floorGrid{grid-template-columns:repeat(2,minmax(250px,1fr));grid-template-areas:"t4 t6" "t3 t5" "t8 t7"}.actions{width:100%;justify-content:flex-start}.actions button,.tabs button{flex:1 1 auto}}
@media(max-width:620px){.floorGrid{grid-template-columns:1fr;grid-template-areas:"t4" "t6" "t8" "t3" "t5" "t7"}.wrap{padding:8px}.top{position:static;align-items:stretch}.brand{min-width:100%}.actions button{flex:1 1 45%}.tabs button{flex:1 1 45%}.card{padding:10px}.slotBtns{grid-template-columns:repeat(2,1fr)}}
@media(pointer:coarse){.floorGrid{gap:12px}.tableCard{border-radius:20px}.slotBtns{gap:10px}.tableCard button{min-height:54px}.pricebtns button,.btns button,.closegrid button{min-height:56px}.slotbtn{min-height:70px}.top{gap:8px}}


</style>
</head>
<body><div id="app" class="app"></div><div id="toast" class="toast"></div><div id="modal" class="modal"><div class="box"><button class="closex" onclick="closeModal()">X</button><div id="modalBody"></div></div></div>
<script>
const T={fr:{subtitle:'Contrôle local - tables 3 à 8',loginTitle:'Connexion quart/admin',password:'Mot de passe',login:'Entrer',logout:'Déconnexion',lang:'EN',allOn:'Tout allumer',allOff:'Tout éteindre',floor:'Tables',reports:'Rapports',admin:'Admin',open:'Ouvrir',close:'Fermer',pause:'Pause',resume:'Reprendre',bill:'Facture',pdf:'PDF',player:'Joueur',players:'Joueurs',add:'Ajouter',remove:'Retirer',update:'Modifier',transfer:'Transférer',transferTable:'Transférer table',to:'Vers',active:'active',off:'fermée',running:'ouverte',paused:'pause',client:'Client',notes:'Notes',payment:'Paiement',cash:'Comptant',card:'Carte',flatUnavailable:'Forfait disponible seulement au bon quart/jour.',daily:'Journalier',shift:'Quart',owner:'Propriétaire',load:'Charger',date:'Date',from:'De',until:'À',pricing:'Tarif',structure:'Structure',search:'Recherche',total:'Total',table:'Table',save:'Sauver',backup:'Backup',events:'Logs',adminOnly:'Admin seulement',relay:'Relais',on:'ON',closeReport:'Close & Report',closeShift:'Fermer le quart',shiftReportId:'ID rapport quart',dayTotal:'Total du jour',shiftTotal:'Total quart',mustCloseTables:'Fermez les tables ouvertes avant de fermer le quart.',offBtn:'OFF',selectedPlayers:'Joueurs sélectionnés',empty:'Vide',cashout:'Encaisser',cashoutCash:'Encaisser CASH',cashoutCard:'Encaisser CARTE',alreadyPaid:'Payé'},en:{subtitle:'Local control - tables 3 to 8',loginTitle:'Shift/admin login',password:'Password',login:'Enter',logout:'Logout',lang:'FR',allOn:'All on',allOff:'All off',floor:'Tables',reports:'Reports',admin:'Admin',open:'Open',close:'Close',pause:'Pause',resume:'Resume',bill:'Bill',pdf:'PDF',player:'Player',players:'Players',add:'Add',remove:'Remove',update:'Update',transfer:'Transfer',transferTable:'Transfer table',to:'To',active:'active',off:'closed',running:'open',paused:'paused',client:'Client',notes:'Notes',payment:'Payment',cash:'Cash',card:'Card',flatUnavailable:'Flat rate only available on the correct shift/day.',daily:'Daily',shift:'Shift',owner:'Owner',load:'Load',date:'Date',from:'From',until:'To',pricing:'Pricing',structure:'Structure',search:'Search',total:'Total',table:'Table',save:'Save',backup:'Backup',events:'Logs',adminOnly:'Admin only',relay:'Relay',on:'ON',closeReport:'Close & Report',closeShift:'Close shift',shiftReportId:'Shift report ID',dayTotal:'Day total',shiftTotal:'Shift total',mustCloseTables:'Close all open tables before closing the shift.',offBtn:'OFF',selectedPlayers:'Joueurs sélectionnés',empty:'Empty',cashout:'Cash out',cashoutCash:'Cash out CASH',cashoutCard:'Cash out CARD',alreadyPaid:'Paid'}};
let app={data:null,lang:localStorage.pool_lang||'fr',tab:'floor',selectedPrice:{},customRate:{},startSlots:{},transferSlots:{},report:null,loginRendered:false,loginBusy:false,busy:0,noAuthSeen:0};
function tr(k){return (T[app.lang]&&T[app.lang][k])||k}function $(s){return document.querySelector(s)}function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}function money(n){let c=app.data?.config?.currency||'$';return c+Number(n||0).toFixed(2)}function dur(sec){sec=Number(sec||0);let h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);return h+'h '+String(m).padStart(2,'0')+'m'}function toast(msg,err=false){let t=$('#toast');t.textContent=msg;t.className='toast'+(err?' err':'');t.style.display='block';setTimeout(()=>t.style.display='none',3200)}
function applyState(s){if(!s)return;if(!s.auth&&app.data&&app.data.auth)s.auth=app.data.auth;app.data=s;app.noAuthSeen=0;}
async function api(path,body=null){let opt={credentials:'same-origin'};if(body!==null){opt.method='POST';opt.headers={'Content-Type':'application/json'};opt.body=JSON.stringify(body)}let r=await fetch(path,opt);let ct=r.headers.get('content-type')||'';let d=ct.includes('application/json')?await r.json():await r.text();if(!r.ok||d.ok===false)throw new Error(d.error||d.message||('HTTP '+r.status));return d}
async function refresh(silent=false){
  if(app.busy>0)return;
  try{
    let wasLoginVisible=!!$('#pw')||app.loginRendered;
    let hadAuth=!!(app.data&&app.data.auth);
    let fresh=await api('/api/state');
    if(!fresh||!fresh.auth){
      if(hadAuth){app.noAuthSeen++;return}
      if(wasLoginVisible){app.loginRendered=true;return}
      renderLogin();return;
    }
    applyState(fresh);
    app.loginRendered=false;
    render();
  }catch(e){if(!silent)toast(e.message,true)}
}
function render(){
  if(!app.data||!app.data.auth){renderLogin();return}
  let isAdmin=app.data.auth.role==='admin';
  if(!isAdmin && (app.tab==='reports'||app.tab==='admin')) app.tab='floor';
  let role=isAdmin?'Admin':app.data.auth.label;
  let adminTabs=isAdmin?`<button class="tab ${app.tab==='reports'?'active':''}" onclick="app.tab='reports';render()">${tr('reports')}</button><button class="tab ${app.tab==='admin'?'active':''}" onclick="app.tab='admin';render()">${tr('admin')}</button>`:'';
  let body=app.tab==='floor'?floorHTML():(isAdmin&&app.tab==='reports')?reportsHTML():(isAdmin&&app.tab==='admin')?adminHTML():floorHTML();
  $('#app').innerHTML=`<div class="top"><div class="brand"><b>SayF Pool Control</b><span>${tr('subtitle')} · ${esc(app.data.current_shift.id.toUpperCase())} ${esc(app.data.current_shift.business_date)}</span></div><div class="actions"><span class="badge">${role}</span><button class="ghost" onclick="toggleLang()">${tr('lang')}</button><button class="primary" onclick="allTables(true)">${tr('allOn')}</button><button class="warn" onclick="allTables(false)">${tr('allOff')}</button><button class="blue" onclick="closeAndReport()">${tr('closeReport')}</button><button class="danger" onclick="logout()">${tr('logout')}</button></div></div><div class="wrap"><div class="tabs"><button class="tab ${app.tab==='floor'?'active':''}" onclick="app.tab='floor';render()">${tr('floor')}</button>${adminTabs}</div>${body}</div>`
}
function renderLogin(){app.loginRendered=true;$('#app').innerHTML=`<div class="login"><h1>${tr('loginTitle')}</h1><p class="muted">Connexion locale protégée. Le champ ne se valide jamais pendant la frappe.</p><label>${tr('password')}</label><form id="loginForm" onsubmit="event.preventDefault();login();return false;"><input id="pw" type="password" autofocus autocomplete="off" autocapitalize="off" spellcheck="false"><div style="height:12px"></div><div class="btns"><button id="loginBtn" class="primary" type="submit">${tr('login')}</button><button class="ghost" type="button" onclick="toggleLang()">${tr('lang')}</button></div><p class="tiny">AM/am = quart AM · PM/pm = quart PM · admin = propriétaire</p></form></div>`;setTimeout(()=>$('#pw')?.focus(),50)}
async function login(){
  if(app.loginBusy)return;
  let pwEl=$('#pw');
  let btn=$('#loginBtn');
  let password=(pwEl?.value||'').trim();
  if(!password){toast('Mot de passe requis.',true);pwEl?.focus();return}
  app.loginBusy=true;if(btn)btn.disabled=true;
  try{let d=await api('/api/login',{password});applyState(d.state);app.loginRendered=false;toast('OK');render()}
  catch(e){toast(e.message,true);if(pwEl){pwEl.focus();pwEl.select()}}
  finally{app.loginBusy=false;if(btn)btn.disabled=false}
}
async function logout(){try{await api('/api/logout',{});app.data=null;app.loginRendered=false;renderLogin()}catch(e){toast(e.message,true)}}function toggleLang(){app.lang=app.lang==='fr'?'en':'fr';localStorage.pool_lang=app.lang;if(!app.data||!app.data.auth){app.loginRendered=false;renderLogin()}else{render()}}async function allTables(on){try{let d=await api('/api/relay/all_tables',{on});applyState(d.state);toast('OK');render()}catch(e){toast(e.message,true)}}
async function closeAndReport(){
  try{
    let d=await api('/api/shift/close_preview',{});
    let sr=d.shift_report||{};
    let ss=sr.summary||{};
    let active=(d.active_tables||[]).map(t=>`<tr><td>Table ${esc(t.table)}</td><td>${esc(t.status)}</td><td>${t.players||0}</td><td style="text-align:right">${money(t.total||0)}</td></tr>`).join('');
    let warn=d.can_close?'':`<div style="background:#ffe4e4;border:1px solid #b3261e;padding:12px;border-radius:12px;margin:12px 0"><b>${tr('mustCloseTables')}</b><table><tr><th>Table</th><th>Statut</th><th>Joueurs</th><th>Total live</th></tr>${active}</table></div>`;
    $('#modalBody').innerHTML=`<div class="invoice"><h2>${tr('closeReport')}</h2><p><b>${esc((d.shift||'').toUpperCase())}</b> · ${esc(d.business_date||'')}</p><div class="line"><span>${tr('shiftReportId')}</span><b>${esc(sr.report_number||'')}</b></div><div class="line"><span>${tr('shiftTotal')}</span><b>${money(ss.total||0)}</b></div><div class="line"><span>Quart sans taxes</span><b>${money(ss.total_without_tax||0)}</b></div><div class="line"><span>Taxes incluses quart</span><b>${money(ss.tax_included||0)}</b></div><div class="line"><span>Ventes enregistrées ce quart</span><b>${esc(ss.count||0)} facture(s)</b></div>${warn}<div class="btns" style="margin-top:16px"><a target="_blank" href="/api/pdf/report?type=shift&date=${encodeURIComponent(d.business_date||'')}&shift=${encodeURIComponent(d.shift||'')}"><button class="primary">PDF quart</button></a><button class="danger" ${d.can_close?'':'disabled'} onclick="closeShiftNow()">${tr('closeShift')}</button></div></div>`;
    $('#modal').style.display='flex';
  }catch(e){toast(e.message,true)}
}
async function closeShiftNow(){
  try{
    await api('/api/shift/close',{});
    app.data=null;app.report=null;app.loginRendered=false;closeModal();renderLogin();toast('Quart fermé.');
  }catch(e){toast(e.message,true)}
}
function floorHTML(){let order={4:1,6:2,8:3,3:4,5:5,7:6};let tables=Object.values(app.data.state.tables).sort((a,b)=>(order[a.number]||99)-(order[b.number]||99)||a.number-b.number);return `<div class="grid floorGrid">${tables.map(tableCard).join('')}</div>`}
function priceButtons(table){
  let catalog=(app.data.pricing_catalog&&app.data.pricing_catalog.length?app.data.pricing_catalog:(app.data.config?.pricing_options||[]).map(o=>({...o,available:(app.data.allowed_pricing||[]).some(a=>a.id===o.id)})));
  let available=catalog.filter(o=>o.available);
  let current=catalog.find(o=>o.id===app.selectedPrice[table.number]);
  if((!current||!current.available)&&available[0])app.selectedPrice[table.number]=(available.find(o=>o.kind==='hourly')||available[0]).id;
  let standard=catalog.map(o=>{
    let av=!!o.available;
    let active=app.selectedPrice[table.number]===o.id;
    let cls=(av?'rate-available':'rate-unavailable')+(active?' active':'');
    let disabled=av?'':'disabled';
    let click=av?`onclick="app.selectedPrice[${table.number}]='${o.id}';delete app.customRate[${table.number}];render()"`:'';
    return `<button class="${cls}" ${disabled} ${click}>${esc(o[app.lang]||o.id)}</button>`;
  }).join('');
  let extraAvailable=catalog.some(o=>o.available&&Number(o.extra_player_fee||0)===7);
  let extraBtn=`<button class="${extraAvailable?'rate-available':'rate-unavailable'}" ${extraAvailable?`onclick="toast('Extra joueur: +7$ appliqué automatiquement avec les tarifs AM.')"`:'disabled'}>+7$ joueur extra</button>`;
  let cr=app.customRate[table.number];
  let customLabel=cr?`CUSTOM ${cr.kind==='flat'?'forfait':'$/h'} ${money(cr.amount)}`:'Tarif custom';
  return `<div class="pricebtns">${extraBtn}${standard}<button class="warn ${app.selectedPrice[table.number]==='custom'?'active':''}" onclick="customRate(${table.number})">${customLabel}</button></div><div class="pricehint">Vert = disponible maintenant · gris = non disponible à ce quart/jour.</div>${cr?`<div class="customBox">Custom actif: <b>${customLabel}</b> · mot de passe validé</div>`:''}`
}
function customRate(n){
  let pw=prompt('Mot de passe tarif custom','');
  if(pw!=='pool'){toast('Mot de passe custom invalide.',true);return}
  let kind=(prompt('Type: h = horaire, f = forfait','h')||'h').toLowerCase().startsWith('f')?'flat':'hourly';
  let amount=Number(prompt(kind==='flat'?'Montant forfait':'Montant par heure','20'));
  if(!amount||amount<=0){toast('Montant invalide.',true);return}
  app.customRate[n]={kind,amount,password:pw};app.selectedPrice[n]='custom';render();
}
function tableCard(t){let on=t.status!=='off';let cls=t.status==='paused'?'paused':on?'on':'';return `<div class="card tableCard table-${t.number} ${cls}" data-table="${t.number}"><div class="titleline"><div><div class="big">${esc(t.name||('Table '+t.number))}</div><div class="tiny">Relais ${esc(t.relay_channel||'')} · max 4 joueurs</div></div><span class="status ${esc(t.status)}">${tr(t.status)||t.status}</span></div>${on?openTableHTML(t):closedTableHTML(t)}</div>`}
function ensureStartSlots(n){
  let arr=(app.startSlots[n]||[1]).map(Number).filter(x=>x>=1&&x<=4);
  arr=[...new Set(arr)].sort((a,b)=>a-b);
  if(!arr.length)arr=[1];
  app.startSlots[n]=arr;
  return arr;
}
function toggleStartSlot(n,slot){
  let arr=ensureStartSlots(n).slice();
  slot=Number(slot);
  if(arr.includes(slot)){
    if(arr.length===1){toast('Il faut au moins 1 joueur.',true);return}
    arr=arr.filter(x=>x!==slot);
  }else{
    arr.push(slot);
  }
  app.startSlots[n]=[...new Set(arr)].sort((a,b)=>a-b);
  render();
}
function startSlotButtons(t){
  let selected=ensureStartSlots(t.number);
  let btns=[1,2,3,4].map(slot=>{
    let sel=selected.includes(slot);
    return `<button type="button" class="slotbtn live ${sel?'selected':''}" onclick="toggleStartSlot(${t.number},${slot})"><b>P${slot}</b><small>${sel?'Actif':'Tap'}</small></button>`;
  }).join('');
  return `<div class="startSlotsBox"><div class="slotTransferTop"><b>Joueurs au départ</b><span class="tiny">${selected.length}/4 sélectionné(s)</span></div><div class="slotBtns">${btns}</div></div>`;
}
function closedTableHTML(t){
  return `<div style="height:10px"></div><div class="money">${money(t.last_total||0)}</div><div class="tiny">Dernière facture / last bill</div><div style="height:10px"></div><label>${tr('client')}</label><input id="client_${t.number}" placeholder="Optionnel" inputmode="text">${startSlotButtons(t)}<label>${tr('pricing')}</label>${priceButtons(t)}<div class="btns"><button class="primary" onclick="startTable(${t.number})">${tr('open')}</button><button class="ghost" onclick="relay(${t.number},true)">${tr('relay')} ${tr('on')}</button><button class="ghost" onclick="relay(${t.number},false)">${tr('relay')} ${tr('offBtn')}</button></div>`
}
function openTableHTML(t){
  let active=activePlayers(t).length;
  let addDisabled=active>=4?'disabled':'';
  return `<div style="height:10px"></div><div class="money">${money(t.due_total??t.total)}</div><div class="no-tax">À encaisser sans taxes: <b>${money((t.due_without_tax??t.total_without_tax)||0)}</b> · taxes incluses: ${money((t.due_tax_included??t.tax_included)||0)} · payé: ${money(t.paid_total||0)} · session: ${money(t.total||0)}</div><div class="tiny">${dur(t.elapsed_seconds)} · ${esc(t.pricing_name_fr||t.pricing_id)} · ${active}/4 ${tr('players')} · totals joueurs en direct</div>${slotTransferHTML(t)}<div class="players">${visiblePlayers(t).map(p=>playerHTML(t,p)).join('')}</div><div class="row"><div class="col-8"><input id="newp_${t.number}" placeholder="Nom joueur optionnel" inputmode="text"></div><div class="col-4"><button class="primary" ${addDisabled} style="width:100%" onclick="addPlayer(${t.number})">${tr('add')}</button></div></div><div style="height:10px"></div><div class="btns"><button class="ghost" onclick="billPreview(${t.number})">${tr('bill')}</button><a target="_blank" href="/api/pdf/active?table=${t.number}"><button class="ghost">${tr('pdf')}</button></a>${t.status==='running'?`<button class="warn" onclick="pause(${t.number})">${tr('pause')}</button>`:`<button class="primary" onclick="resume(${t.number})">${tr('resume')}</button>`}</div><div style="height:10px"></div><div class="closegrid"><button class="danger" onclick="closeTable(${t.number},'cash')">Fermer CASH</button><button class="danger" onclick="closeTable(${t.number},'card')">Fermer CARTE</button><button class="ghost full" onclick="closeTable(${t.number},'unpaid')">Fermer NON PAYÉ</button></div>`
}
function activePlayers(t){return (t.players||[]).filter(p=>p.active!==false)}
function visiblePlayers(t){return (t.players||[]).filter(p=>p.active!==false||p.cashed_out||p.cashout_bill_number)}
function playerSlot(p){let m=String(p.id||'').match(/P(\d+)$/);return Number(p.slot||((m&&m[1])||0))}
function selectedSlots(t){
  let valid=new Set(activePlayers(t).map(p=>playerSlot(p)));
  let arr=(app.transferSlots[t.number]||[]).map(Number).filter(slot=>valid.has(slot));
  arr=[...new Set(arr)].sort((a,b)=>a-b);
  app.transferSlots[t.number]=arr;
  return arr;
}
function selectedIds(t){
  let bySlot={};activePlayers(t).forEach(p=>{bySlot[playerSlot(p)]=String(p.id)});
  return selectedSlots(t).map(slot=>bySlot[slot]).filter(Boolean);
}
function toggleSlot(tn,slot){
  slot=Number(slot);
  if(!slot)return;
  let table=app.data?.state?.tables?.[String(tn)]||app.data?.state?.tables?.[tn];
  if(!table)return;
  let valid=new Set(activePlayers(table).map(p=>playerSlot(p)));
  if(!valid.has(slot))return;
  let arr=(app.transferSlots[tn]||[]).map(Number);
  app.transferSlots[tn]=arr.includes(slot)?arr.filter(x=>x!==slot):[...arr,slot];
  app.transferSlots[tn]=[...new Set(app.transferSlots[tn])].sort((a,b)=>a-b);
  render();
}
function slotTransferHTML(t){
  let players=activePlayers(t);let bySlot={};players.forEach(p=>{bySlot[playerSlot(p)]=p});let selected=selectedSlots(t);let targets=Object.values(app.data.state.tables).filter(x=>x.number!==t.number);let btns=[1,2,3,4].map(slot=>{let p=bySlot[slot];let sel=!!p&&selected.includes(slot);let cls=`slotbtn ${p?'live':'empty'} ${sel?'selected':''}`;let name=p?esc(p.name||p.id):tr('empty');return `<button type="button" class="${cls}" ${p?'':'disabled'} onclick="toggleSlot(${t.number},${slot})"><b>P${slot}</b><small>${p?esc(p.id):''}</small><small>${name}</small></button>`}).join('');
  return `<div class="slotTransfer"><div class="slotTransferTop"><b>${tr('transfer')} ${tr('players')}</b><span class="tiny">${selected.length}/4 ${tr('selectedPlayers')}</span></div><div class="slotBtns">${btns}</div><div class="transferControls"><select id="multi_to_${t.number}">${targets.map(x=>`<option value="${x.number}">Table ${x.number}</option>`).join('')}</select><button class="blue" ${selected.length?'':'disabled'} onclick="transferSelectedPlayers(${t.number})">${tr('transfer')} ${selected.length?`(${selected.length})`:''}</button></div><p class="tiny">Sélectionne P1/P2/P3/P4. Plusieurs boutons peuvent rester verts en même temps.</p></div>`
}
function playerHTML(t,p){
  let inactive=p.active===false;
  let paid=p.cashed_out||p.cashout_bill_number;
  let due=Number(p.running_total||0);
  let dueNoTax=Number(p.running_without_tax||0);
  let dueTax=Number(p.running_tax_included||0);
  let paidAmt=Number(p.cashout_total||p.paid_total||0);
  let totalBlock=paid
    ? `<div class="playerTotal paid"><b>PAYÉ ${money(paidAmt)}</b><small>sans taxes ${money(p.cashout_without_tax||paidAmt/1.15)}</small></div>`
    : `<div class="playerTotal"><b>${money(due)}</b><small>sans taxes ${money(dueNoTax)} · taxes ${money(dueTax)}</small></div>`;
  return `<div class="playerEdit ${inactive?'off':''}"><span class="slotid">${esc(p.id||'')}</span><input value="${esc(p.name)}" ${inactive?'disabled':''} onchange="updatePlayer(${t.number},'${p.id}',this.value)">${totalBlock}<button class="primary" ${inactive?'disabled':''} onclick="cashoutPlayer(${t.number},'${p.id}','cash')">${tr('cashoutCash')}</button><button class="blue" ${inactive?'disabled':''} onclick="cashoutPlayer(${t.number},'${p.id}','card')">${tr('cashoutCard')}</button><button class="danger" ${inactive?'disabled':''} onclick="removePlayer(${t.number},'${p.id}')">${tr('remove')}</button></div>`
}
async function startTable(n){
  let slots=ensureStartSlots(n).slice().sort((a,b)=>a-b);
  let names=slots.map(slot=>'Joueur '+slot);
  let client=$('#client_'+n).value||names[0]||'';
  let body={table:n,client,players:names,player_slots:slots,pricing_id:app.selectedPrice[n]};
  if(app.selectedPrice[n]==='custom'&&app.customRate[n]){body.custom_rate={kind:app.customRate[n].kind,amount:app.customRate[n].amount,password:app.customRate[n].password};body.custom_password=app.customRate[n].password;}
  app.busy++;
  try{let d=await api('/api/table/start',body);applyState(d.state);app.transferSlots[n]=[];toast(d.message);render()}catch(e){toast(e.message,true)}finally{app.busy=Math.max(0,app.busy-1)}
}
async function pause(n){try{let d=await api('/api/table/pause',{table:n});applyState(d.state);toast(d.message);render()}catch(e){toast(e.message,true)}}
async function resume(n){try{let d=await api('/api/table/resume',{table:n});applyState(d.state);toast(d.message);render()}catch(e){toast(e.message,true)}}
async function closeTable(n,pm='cash'){try{let d=await api('/api/table/stop',{table:n,payment_method:pm});applyState(d.state);toast(d.message);showInvoice(d.receipt);render()}catch(e){toast(e.message,true)}}
async function cashoutPlayer(t,pid,pm='cash'){
  try{
    let d=await api('/api/player/cashout',{table:t,player_id:pid,payment_method:pm});
    applyState(d.state);toast(d.message);showInvoice(d.receipt);render();
  }catch(e){toast(e.message,true)}
}
async function addPlayer(n){try{let d=await api('/api/player/add',{table:n,name:$('#newp_'+n).value});applyState(d.state);toast(d.message);render()}catch(e){toast(e.message,true)}}
async function updatePlayer(t,pid,name){try{let d=await api('/api/player/update',{table:t,player_id:pid,name});applyState(d.state);toast(d.message)}catch(e){toast(e.message,true)}}
async function removePlayer(t,pid){try{let d=await api('/api/player/remove',{table:t,player_id:pid});applyState(d.state);toast(d.message);render()}catch(e){toast(e.message,true)}}
async function transferSelectedPlayers(t){
  let src=app.data.state.tables[String(t)]||app.data.state.tables[t];
  if(!src){toast('Table source introuvable.',true);return}
  let ids=selectedIds(src);
  if(!ids.length){toast('Sélectionne P1/P2/P3/P4 avant de transférer.',true);return}
  let to=Number($('#multi_to_'+t)?.value||0);
  let dst=app.data.state.tables[String(to)]||app.data.state.tables[to];
  if(!dst||to===t){toast('Table destination invalide.',true);return}
  let srcActive=activePlayers(src).length;
  let dstActive=dst.status==='off'?0:activePlayers(dst).length;
  let capacity=4-dstActive;
  if(ids.length>capacity){toast(`Table ${to}: seulement ${capacity} place(s) libre(s).`,true);return}
  let slots={};activePlayers(src).forEach(p=>{slots[String(p.id)]=playerSlot(p)});
  ids=ids.slice().sort((a,b)=>(slots[b]||0)-(slots[a]||0));
  app.busy++;
  try{
    let last=null;
    if(ids.length===srcActive){
      if(dst.status!=='off'){throw new Error('Pour transférer tous les joueurs, la table destination doit être fermée.')}
      last=await api('/api/table/transfer',{from_table:t,to_table:to});
      applyState(last.state);
      toast('Table complète transférée.');
    }else{
      for(const pid of ids){last=await api('/api/player/transfer',{from_table:t,to_table:to,player_id:pid});applyState(last.state)}
      toast(`${ids.length} joueur(s) transféré(s).`);
    }
    app.transferSlots[t]=[];app.transferSlots[to]=[];
    render();
  }catch(e){toast(e.message,true);render()}
  finally{app.busy=Math.max(0,app.busy-1)}
}
async function relay(t,on){try{await api('/api/relay/set',{table:t,on});toast('OK');refresh(true)}catch(e){toast(e.message,true)}}
async function billPreview(t){try{let d=await api('/api/bill/active?table='+t);showInvoice(d.bill)}catch(e){toast(e.message,true)}}
function showInvoice(r){let cfg=app.data.config;let players=(r.players||[]).map(p=>`<tr><td><b>${esc(p.id||'')}</b></td><td>${esc(p.name)}</td><td>${p.cashed_out?'encaissé':(p.active===false?'retiré':'actif')}</td></tr>`).join('');let pb=(r.player_bills||[]).map(p=>`<tr><td>${esc(p.player_id||'')}</td><td>${esc(p.player_name)}</td><td>${esc(p.bill_number)}</td><td style="text-align:right">${money(p.share_total)}</td><td style="text-align:right">${money(p.share_total_without_tax||((p.share_total||0)/1.15))}</td><td><a target="_blank" href="/api/pdf/player?session_id=${r.session_id||''}&table=${r.preview?r.table:''}&player_id=${p.player_id||''}">PDF</a></td></tr>`).join('');let cashouts=(r.player_cashouts||[]).map(c=>`<tr><td>${esc(c.player_id||'')}</td><td>${esc(c.player_name||'')}</td><td>${esc(c.bill_number||'')}</td><td style="text-align:right">${money(c.total||0)}</td></tr>`).join('');let original=(r.original_session_total!=null)?`<tr><td>Total session complète</td><td>${money(r.original_session_total||0)}</td></tr><tr><td>Déjà encaissé</td><td>${money(r.prior_paid_total||0)}</td></tr>`:'';$('#modalBody').innerHTML=`<div class="invoice"><h2>${cfg.business_name||'Billard'} - ${tr('bill')}</h2><p><b>${esc(r.bill_number)}</b>${r.preview?' · PREFACTURE':''}</p><div class="line"><span>${tr('table')}</span><b>${r.table}</b></div><div class="line"><span>${tr('client')}</span><b>${esc(r.client||'')}</b></div><div class="line"><span>${tr('pricing')}</span><b>${esc(r.pricing_name_fr||r.pricing_id)}</b></div><div class="line"><span>Durée</span><b>${dur(r.duration_seconds)}</b></div><table><tr><th>Description</th><th>Total</th></tr>${original}<tr><td>Total sans taxes (total / 1.15)</td><td>${money(r.total_without_tax||0)}</td></tr><tr><td>Taxes incluses</td><td>${money(r.tax_included||0)}</td></tr><tr><td><b>Total à encaisser</b></td><td><b>${money(r.total)}</b></td></tr></table><p class="total">${money(r.total)}</p><h3>${tr('players')}</h3><table><tr><th>ID</th><th>Nom</th><th>Statut</th></tr>${players}</table>${cashouts?`<h3>Déjà encaissé</h3><table><tr><th>ID</th><th>Joueur</th><th>No.</th><th>Total</th></tr>${cashouts}</table>`:''}<h3>Factures joueurs</h3><table><tr><th>ID</th><th>Joueur</th><th>No.</th><th>Part</th><th>Sans taxes</th><th>PDF</th></tr>${pb}</table><p><a target="_blank" href="/api/pdf/session?session_id=${r.session_id||''}&table=${r.preview?r.table:''}">PDF facture table</a></p></div>`;$('#modal').style.display='flex'}function closeModal(){$('#modal').style.display='none'}
function reportsHTML(){let cfg=app.data.config;let today=app.data.current_shift.business_date;return `<div class="split"><div class="card"><h2>${tr('reports')}</h2><div class="row"><div class="col-3"><label>${tr('date')}</label><input type="date" id="rdate" value="${today}"></div><div class="col-3"><label>${tr('shift')}</label><select id="rshift"><option value="am">AM</option><option value="pm">PM</option></select></div><div class="col-6 btns" style="align-items:end"><button class="primary" onclick="loadShiftReport()">${tr('shift')}</button><button class="blue" onclick="loadDailyReport()">${tr('daily')}</button><a id="pdfLink" target="_blank"></a></div></div>${app.data.auth.role==='admin'?`<hr style="border-color:var(--line)"><h3>${tr('owner')}</h3><div class="row"><div class="col-3"><label>${tr('from')}</label><input type="date" id="ofrom"></div><div class="col-3"><label>${tr('until')}</label><input type="date" id="oto" value="${today}"></div><div class="col-3"><label>${tr('pricing')}</label><select id="opricing"><option value="all">Tous</option>${cfg.pricing_options.map(p=>`<option value="${p.id}">${esc(p.fr)}</option>`).join('')}</select></div><div class="col-3"><label>${tr('structure')}</label><select id="okind"><option value="all">Tous</option><option value="hourly">Horaire</option><option value="flat">Forfait</option></select></div><div class="col-3"><label>${tr('shift')}</label><select id="oshift"><option value="all">Tous</option><option value="am">AM</option><option value="pm">PM</option></select></div><div class="col-6"><label>${tr('search')}</label><input id="otext" placeholder="facture, table, client"></div><div class="col-3" style="display:flex;align-items:end"><button class="primary" style="width:100%" onclick="loadOwnerReport()">${tr('load')}</button></div></div>`:''}</div><div class="card" id="reportOut">${renderReport(app.report)}</div></div>`}
async function loadShiftReport(){if(app.data?.auth?.role!=='admin'){toast(tr('adminOnly'),true);return}let d=$('#rdate').value, s=$('#rshift').value;try{app.report=await api(`/api/reports/shift?date=${encodeURIComponent(d)}&shift=${encodeURIComponent(s)}`);render()}catch(e){toast(e.message,true)}}async function loadDailyReport(){if(app.data?.auth?.role!=='admin'){toast(tr('adminOnly'),true);return}let d=$('#rdate').value;try{app.report=await api(`/api/reports/daily?date=${encodeURIComponent(d)}`);render()}catch(e){toast(e.message,true)}}async function loadOwnerReport(){if(app.data?.auth?.role!=='admin'){toast(tr('adminOnly'),true);return}let q=new URLSearchParams({from:$('#ofrom').value,to:$('#oto').value,pricing_id:$('#opricing').value,pricing_kind:$('#okind').value,shift:$('#oshift').value,text:$('#otext').value});try{app.report=await api('/api/reports/owner?'+q.toString());render()}catch(e){toast(e.message,true)}}function renderReport(r){if(!r)return `<p class="muted">Charge un rapport.</p>`;let s=r.summary||{};let pdf='#';if(r.type==='shift')pdf=`/api/pdf/report?type=shift&date=${r.date}&shift=${r.shift}`;if(r.type==='daily')pdf=`/api/pdf/report?type=daily&date=${r.date}`;if(r.type==='owner'){let f=r.filters||{};pdf='/api/pdf/report?type=owner&'+new URLSearchParams(f).toString()}let rows=(r.sessions||[]).map(x=>`<tr><td>${esc(x.bill_number)}</td><td>${esc(x.business_date)}</td><td>${esc(x.shift_id)}</td><td>${esc(x.table)}</td><td>${esc(x.pricing_id)}</td><td>${esc(x.pricing_kind)}</td><td>${money(x.total_without_tax||0)}</td><td>${money(x.tax_included||0)}</td><td>${money(x.total)}</td><td><a target="_blank" href="/api/pdf/session?session_id=${x.session_id}">PDF</a></td></tr>`).join('');let tt=Object.entries(s.table_totals||{}).map(([k,v])=>`<div>Table ${k}<b>${money(v)}</b></div>`).join('');return `<h2>${esc(r.report_number)}</h2><div class="kpi"><div>Sessions<b>${s.count||0}</b></div><div>${tr('total')}<b>${money(s.total||0)}</b></div><div>Sans taxes<b>${money(s.total_without_tax||0)}</b></div><div>Taxes incluses<b>${money(s.tax_included||0)}</b></div>${tt}</div><p><a target="_blank" href="${pdf}"><button class="primary">PDF rapport</button></a> <a target="_blank" href="/api/export/sessions.csv"><button>CSV</button></a></p><div class="tablewrap"><table class="report-table"><thead><tr><th>Facture</th><th>Date</th><th>Quart</th><th>Table</th><th>Tarif</th><th>Structure</th><th>Sans taxes</th><th>Taxes</th><th>Total</th><th>PDF</th></tr></thead><tbody>${rows}</tbody></table></div>`}
function adminHTML(){if(app.data.auth.role!=='admin')return `<div class="card"><h2>${tr('adminOnly')}</h2></div>`;let cfg=app.data.config;return `<div class="card"><h2>${tr('admin')}</h2><p class="muted">Panneau propriétaire: relais, exports, backups, logs, configuration JSON. Staff ne voit pas ces contrôles.</p><div class="row"><div class="col-4"><label>Nom commerce</label><input id="biz" value="${esc(cfg.business_name)}"></div><div class="col-2"><label>Tax %</label><input id="tax" type="number" step="0.01" value="${esc(cfg.tax_percent)}"></div><div class="col-2"><label>Arrondi</label><input id="rounding" type="number" step="0.01" value="${esc(cfg.rounding)}"></div><div class="col-4" style="display:flex;align-items:end"><button class="primary" onclick="saveBasicConfig()">${tr('save')}</button></div></div><hr style="border-color:var(--line)"><h3>${tr('relay')}</h3><div class="btns">${[1,2,3,4,5,6,7,8].map(ch=>`<button onclick="relayChannel(${ch},true)">CH${ch} ON</button><button onclick="relayChannel(${ch},false)">CH${ch} OFF</button>`).join('')}</div><hr style="border-color:var(--line)"><div class="btns"><button onclick="backup()">${tr('backup')}</button><a target="_blank" href="/api/export/events.jsonl"><button>${tr('events')}</button></a><a target="_blank" href="/api/export/config.json"><button>config.json</button></a><a target="_blank" href="/api/export/sessions.csv"><button>sessions.csv</button></a></div></div>`}
async function saveBasicConfig(){try{let d=await api('/api/admin/basic_config',{business_name:$('#biz').value,tax_percent:Number($('#tax').value||0),rounding:Number($('#rounding').value||0.05)});applyState(d.state);toast('OK');render()}catch(e){toast(e.message,true)}}async function relayChannel(ch,on){try{await api('/api/relay/set',{channel:ch,on});toast('OK')}catch(e){toast(e.message,true)}}async function backup(){try{let d=await api('/api/admin/backup',{});toast('Backup: '+d.folder)}catch(e){toast(e.message,true)}}
setInterval(()=>refresh(true),3000);refresh();
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    server_version = "SayFPool/2.0"

    def log_message(self, fmt, *args):
        if getattr(self.server, "quiet", False):
            return
        super().log_message(fmt, *args)

    def _send(self, status=200, body=b"", content_type="application/json; charset=utf-8", headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, data, status=200, headers=None):
        self._send(status, json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", headers)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    def _state_with_auth(self, user=None) -> dict:
        data = enrich_state()
        data["auth"] = user or current_user(self.headers)
        return data

    def do_GET(self):
        ensure_runtime()
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        user = current_user(self.headers)
        try:
            if path in ("/", "/index.html"):
                self._send(200, HTML, "text/html; charset=utf-8")
            elif path == "/api/state":
                self._json(self._state_with_auth(user))
            elif path == "/api/bill/active":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                table = int((qs.get("table") or [0])[0])
                self._json({"ok": True, "bill": active_bill(table)})
            elif path == "/api/reports/shift":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                date = (qs.get("date") or [current_shift()[1]])[0]
                shift = (qs.get("shift") or [current_shift()[0]])[0]
                self._json(shift_report(date, shift))
            elif path == "/api/reports/daily":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                date = (qs.get("date") or [current_shift()[1]])[0]
                self._json(daily_report(date))
            elif path == "/api/reports/owner":
                ok, user, err = require_admin(self.headers)
                if not ok:
                    self._json(err, 403 if user else 401); return
                query = {k: (v[0] if v else "") for k, v in qs.items()}
                self._json(owner_report(query))
            elif path == "/api/pdf/session":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                sid = (qs.get("session_id") or [""])[0]
                table = (qs.get("table") or [""])[0]
                row = active_bill(int(table)) if table else find_session(sid)
                if not row:
                    self._json({"ok": False, "error": "Facture introuvable."}, 404); return
                pdf = pdf_receipt(row)
                name = f"facture_{row.get('bill_number','table')}.pdf".replace("/", "_")
                self._send(200, pdf, "application/pdf", {"Content-Disposition": f"inline; filename={name}"})
            elif path == "/api/pdf/player":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                sid = (qs.get("session_id") or [""])[0]
                pid = (qs.get("player_id") or [""])[0]
                row = find_session(sid)
                if not row:
                    table = (qs.get("table") or [""])[0]
                    if table:
                        row = active_bill(int(table))
                    else:
                        st = load_state()
                        for tv in st.get("tables", {}).values():
                            if tv.get("session_id") == sid and tv.get("status") != "off":
                                row = active_bill(int(tv.get("number")))
                                break
                if not row:
                    self._json({"ok": False, "error": "Facture introuvable."}, 404); return
                pdf = pdf_receipt(row, player_id=pid)
                self._send(200, pdf, "application/pdf", {"Content-Disposition": "inline; filename=facture_joueur.pdf"})
            elif path == "/api/pdf/active":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                table = int((qs.get("table") or [0])[0])
                row = active_bill(table)
                pdf = pdf_receipt(row)
                self._send(200, pdf, "application/pdf", {"Content-Disposition": f"inline; filename=prefacture_table_{table}.pdf"})
            elif path == "/api/pdf/report":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                rtype = (qs.get("type") or ["daily"])[0]
                if rtype == "shift":
                    rep = shift_report((qs.get("date") or [current_shift()[1]])[0], (qs.get("shift") or [current_shift()[0]])[0])
                elif rtype == "owner":
                    if user.get("role") != "admin":
                        self._json({"ok": False, "error": "Accès admin requis."}, 403); return
                    query = {k: (v[0] if v else "") for k, v in qs.items()}
                    rep = owner_report(query)
                else:
                    rep = daily_report((qs.get("date") or [current_shift()[1]])[0])
                pdf = pdf_report(rep)
                name = f"rapport_{rep.get('report_number','report')}.pdf".replace("/", "_")
                self._send(200, pdf, "application/pdf", {"Content-Disposition": f"inline; filename={name}"})
            elif path == "/api/export/sessions.csv":
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                self._send(200, csv_sessions(), "text/csv; charset=utf-8", {"Content-Disposition": "attachment; filename=sessions.csv"})
            elif path == "/api/export/events.jsonl":
                ok, user, err = require_admin(self.headers)
                if not ok:
                    self._json(err, 403 if user else 401); return
                body = EVENTS_PATH.read_text(encoding="utf-8") if EVENTS_PATH.exists() else ""
                self._send(200, body, "application/x-ndjson; charset=utf-8", {"Content-Disposition": "attachment; filename=events.jsonl"})
            elif path == "/api/export/config.json":
                ok, user, err = require_admin(self.headers)
                if not ok:
                    self._json(err, 403 if user else 401); return
                self._send(200, CONFIG_PATH.read_text(encoding="utf-8"), "application/json; charset=utf-8", {"Content-Disposition": "attachment; filename=config.json"})
            else:
                self._json({"ok": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"ok": False, "error": str(exc)}, 500)

    def do_POST(self):
        ensure_runtime()
        parsed = urlparse(self.path)
        path = parsed.path
        body = self._body()
        try:
            if path == "/api/login":
                password = str(body.get("password") or "")
                user = check_login(password)
                if not user:
                    self._json({"ok": False, "error": "Mot de passe invalide."}, 403); return
                sid = secrets.token_urlsafe(24)
                AUTH_TOKENS[sid] = user
                event("shift_sign_in" if user.get("role") == "staff" else "admin_sign_in", None, user)
                self._json({"ok": True, "state": self._state_with_auth(user)}, headers={"Set-Cookie": f"pool_sid={sid}; Path=/; HttpOnly; SameSite=Strict"})
            elif path == "/api/logout":
                user = current_user(self.headers)
                raw = self.headers.get("Cookie") or ""
                c = cookies.SimpleCookie(); c.load(raw)
                sid = c.get("pool_sid")
                if sid and sid.value in AUTH_TOKENS:
                    AUTH_TOKENS.pop(sid.value, None)
                if user:
                    event("shift_sign_out" if user.get("role") == "staff" else "admin_sign_out", None, user)
                self._json({"ok": True}, headers={"Set-Cookie": "pool_sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"})
            else:
                ok, user, err = require_user(self.headers)
                if not ok:
                    self._json(err, 401); return
                if path == "/api/shift/close_preview":
                    self._json(close_report_preview(user))
                elif path == "/api/shift/close":
                    try:
                        preview = close_shift_with_report(user)
                    except ValueError as exc:
                        self._json({"ok": False, "error": str(exc)}, 400); return
                    raw = self.headers.get("Cookie") or ""
                    c = cookies.SimpleCookie(); c.load(raw)
                    sid = c.get("pool_sid")
                    if sid and sid.value in AUTH_TOKENS:
                        AUTH_TOKENS.pop(sid.value, None)
                    self._json(preview, headers={"Set-Cookie": "pool_sid=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"})
                elif path == "/api/table/start":
                    ok2, msg, data = start_table(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/table/pause":
                    ok2, msg, data = pause_table(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/table/resume":
                    ok2, msg, data = resume_table(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/table/stop":
                    ok2, msg, data = stop_table(body, user)
                    if ok2:
                        self._json({"ok": True, "message": msg, "state": data["state"], "receipt": data["receipt"]})
                    else:
                        self._json({"ok": False, "error": msg}, 400)
                elif path == "/api/table/transfer":
                    ok2, msg, data = transfer_table(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/table/adjust":
                    ok2, msg, data = add_adjustment(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/player/add":
                    ok2, msg, data = add_player(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/player/update":
                    ok2, msg, data = update_player(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/player/remove":
                    ok2, msg, data = remove_player(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/player/cashout":
                    ok2, msg, data = cashout_player(body, user)
                    if ok2:
                        self._json({"ok": True, "message": msg, "state": data["state"], "receipt": data["receipt"]})
                    else:
                        self._json({"ok": False, "error": msg}, 400)
                elif path == "/api/player/transfer":
                    ok2, msg, data = transfer_player(body, user)
                    self._json({"ok": ok2, "message": msg, **({"state": data} if data else {})}, 200 if ok2 else 400)
                elif path == "/api/relay/set":
                    res = relay_action(body, user)
                    self._json(res, 200 if res.get("ok") else 500)
                elif path == "/api/relay/all_tables":
                    self._json(set_all_table_relays(body, user))
                elif path == "/api/admin/backup":
                    if user.get("role") != "admin":
                        self._json({"ok": False, "error": "Accès admin requis."}, 403); return
                    self._json(backup_now())
                elif path == "/api/admin/basic_config":
                    if user.get("role") != "admin":
                        self._json({"ok": False, "error": "Accès admin requis."}, 403); return
                    cfg = load_config()
                    cfg["business_name"] = str(body.get("business_name") or cfg.get("business_name") or "Billard")
                    cfg["tax_percent"] = float(body.get("tax_percent") or 0)
                    cfg["rounding"] = float(body.get("rounding") or 0.05)
                    save_json(CONFIG_PATH, cfg)
                    event("admin_basic_config", None, user)
                    self._json({"ok": True, "state": self._state_with_auth(user)})
                else:
                    self._json({"ok": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"ok": False, "error": str(exc)}, 500)


def open_browser(url: str):
    system = platform.system().lower()
    candidates = []
    if system == "windows":
        candidates = [
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        ]
    elif system == "darwin":
        candidates = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    else:
        for cmd in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge", "brave-browser"):
            p = shutil.which(cmd)
            if p:
                candidates.append(p)
    for exe in candidates:
        if exe and (Path(exe).exists() or shutil.which(exe)):
            try:
                subprocess.Popen([exe, f"--app={url}", "--start-maximized", "--disable-infobars"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except Exception:
                pass
    webbrowser.open(url)


def main():
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    ensure_runtime()
    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    httpd.quiet = args.quiet
    url = f"http://{args.host}:{args.port}"
    print(f"\n{APP_NAME} {APP_VERSION}")
    print(f"URL: {url}")
    print(f"Runtime: {DATA_DIR}")
    print("Passwords: AM/am | PM/pm | Admin=admin | Custom rate=pool")
    print("CTRL+C pour fermer.\n")
    if not args.no_browser:
        threading.Timer(0.8, lambda: open_browser(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur.")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
